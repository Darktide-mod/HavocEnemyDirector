-- Data only. Imported files are never evaluated as Lua.
local C={format="HavocEnemyDirector.Template",version=1,max_bytes=262144,max_files=256}
local function fail(where) error("template_invalid: "..where,0) end
local function object(v,where) if type(v)~="table" or getmetatable(v) then fail(where) end; return v end
local function fields(v,allowed,where)
    object(v,where)
    for k in pairs(v) do if not allowed[k] then fail(where.."."..tostring(k)) end end
end
local function keys(s) local t={} for k in s:gmatch("%S+") do t[k]=true end return t end
local function number(n,lo,hi,integer,where)
    if type(n)~="number" or n~=n or n<lo or n>hi or integer and n%1~=0 then fail(where) end
    return n
end
local function identifier(s,where)
    if type(s)~="string" or #s>180 or not s:match("^[%w_]+$") then fail(where) end
end
local function array(t,limit,where)
    object(t,where); local count=0
    for k in pairs(t) do number(k,1,limit,true,where); count=count+1 end
    if #t~=count then fail(where) end
    return t
end
function C.name(s)
    if type(s)~="string" then return nil end
    s=s:match("^%s*(.-)%s*$")
    if s=="" or #s>256 or s:find('[%z\1-\31<>:"/\\|?*]') or s:match("[%. ]$") then return nil end
    local n=0; for _ in s:gmatch(".[\128-\191]*") do n=n+1 end
    local stem=(s:match("^([^%.]+)") or ""):upper()
    if n>64 or stem=="CON" or stem=="PRN" or stem=="AUX" or stem=="NUL" or stem:match("^COM[1-9]$") or stem:match("^LPT[1-9]$") then return nil end
    return s
end
function C.filename(s)
    return type(s)=="string" and s:sub(-5):lower()==".json" and C.name(s:sub(1,-6))~=nil
end
function C.validate(value,P,breeds)
    local ok,result=pcall(function()
        fields(value,keys("format version name config context"),"root")
        if value.format~=C.format or value.version~=C.version then error("template_version",0) end
        local name=C.name(value.name); if not name then error("template_name_invalid",0) end
        local v=object(value.config,"config")
        fields(v,keys("enabled native_extras_enabled havoc_twins_enabled total_cap category_caps capacity_multipliers capacity_preset_version generators custom banned revision next_id conditions_signature"),"config")
        for _,k in ipairs({"enabled","native_extras_enabled","havoc_twins_enabled"}) do
            if type(v[k])~="boolean" then fail(k) end
        end
        number(v.total_cap,1,P.capacity_limit,true,"total_cap")
        local cats=keys("common elite special boss")
        for _,k in ipairs({"category_caps","capacity_multipliers"}) do
            fields(v[k],cats,k)
            for c in pairs(cats) do number(v[k][c],k=="category_caps" and 0 or 1,k=="category_caps" and P.capacity_limit or 5,true,k.."."..c) end
        end
        local function pool(t)
            object(t,"pool"); local n=0
            for id,w in pairs(t) do
                identifier(id,"unit"); n=n+1; if n>512 then fail("pool") end
                if not breeds[id] then error("template_unit_missing: "..id,0) end
                number(w,0,10000,false,"weight")
            end
        end
        local seen={}
        for _,g in ipairs(array(v.custom,128,"custom")) do
            fields(g,keys("id category kind pool"),"custom generator")
            if type(g.id)~="string" or not g.id:match("^custom_[1-9]%d*$") or #g.id>20 or seen[g.id] then fail("custom id") end
            if not cats[g.category] or g.kind~="timer" and g.kind~="travel" then fail("custom kind/category") end
            seen[g.id]=true; pool(g.pool)
        end
        object(v.generators,"generators"); local count=0
        for id,g in pairs(v.generators) do
            identifier(id,"generator id"); count=count+1; if count>256 then fail("generators") end
            fields(g,keys("enabled deleted count interval distance cap pool"),"generator")
            for _,k in ipairs({"enabled","deleted"}) do if g[k]~=nil and type(g[k])~="boolean" then fail(k) end end
            for k,bounds in pairs({count={1,100,true},interval={1,3600},distance={0,2000},cap={0,P.capacity_limit,true}}) do
                if g[k]~=nil then number(g[k],bounds[1],bounds[2],bounds[3],k) end
            end
            if g.pool then pool(g.pool) end
        end
        object(v.banned,"banned")
        for id,b in pairs(v.banned) do identifier(id,"ban"); if not breeds[id] then error("template_unit_missing: "..id,0) end; if type(b)~="boolean" then fail("ban") end end
        local x=value.context
        fields(x,keys("conditions environment faction scaling"),"context")
        local ids={}
        for _,id in ipairs(array(x.conditions,256,"conditions")) do identifier(id,"condition"); if ids[id] then fail("duplicate condition") end; ids[id]=true end
        identifier(x.environment,"environment"); identifier(x.faction,"faction")
        fields(x.scaling,cats,"scaling")
        for c in pairs(cats) do
            local f=x.scaling[c]; fields(f,keys("multiplier mode"),"scaling")
            number(f.multiplier,1,5,true,"multiplier")
            if f.mode~="quantity" and f.mode~="speed" and f.mode~="mixed" then fail("mode") end
        end
        -- Revision, next ID and condition signature are local bookkeeping.
        local raw=P.copy(v); raw.revision=1; raw.next_id=nil; raw.conditions_signature=nil; raw.capacity_preset_version=1
        for c in pairs(cats) do raw.capacity_multipliers[c]=x.scaling[c].multiplier end
        return {format=C.format,version=C.version,name=name,config=P.config(raw),context=P.copy(x)}
    end)
    if ok then return result end
    return nil,tostring(result)
end
function C.decode(text,P,breeds,json)
    if type(text)~="string" or #text>C.max_bytes then return nil,"template_too_large" end
    text=text:gsub("^\239\187\191","")
    local ok,v=pcall(json.decode,text)
    if not ok then return nil,"template_json_invalid" end
    return C.validate(v,P,breeds)
end
return C
