local mod=get_mod("HavocEnemyDirector")
local L={
    mod_name={en="Havoc Enemy Director",["zh-cn"]="浩劫原版模板编辑器",["zh-tw"]="浩劫原版範本編輯器"},
    mod_description={en="Fine control of native enemy templates, compositions and trigger conditions. Requires Havoc Condition Manager. Changes apply next mission.",["zh-cn"]="精调原版敌人模板、编成和触发条件。需要浩劫词条管理器；修改在下一局生效。",["zh-tw"]="精調原版敵人範本、編成和觸發條件。需要浩劫詞條管理器；修改在下一局生效。"},
    director_open={en="Open native template editor",["zh-cn"]="打开原版模板编辑器",["zh-tw"]="開啟原版範本編輯器"},
    open={en="Open",["zh-cn"]="打开",["zh-tw"]="開啟"},
    toggle_next_mission={en="Switch saved. The current mission keeps its configuration; the new state applies next mission.",["zh-cn"]="开关已保存；当前任务保持原配置，下一局应用新的开关状态。",["zh-tw"]="開關已儲存；目前任務保持原設定，下一局套用新的開關狀態。"},
}
for key,value in pairs(mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/preset_localization")) do L[key]=value end
return L
