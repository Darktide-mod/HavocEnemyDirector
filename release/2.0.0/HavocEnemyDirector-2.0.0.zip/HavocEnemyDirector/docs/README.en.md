# Havoc Enemy Director

Edit native enemy templates for SoloPlay and Realms from HCM's Native template editor page. HED supplies exact field overrides and trigger rules; HCM provides broad multipliers. Both use the game's existing spawn systems.

## Editor controls

**Open Havoc Enemy Director in Mod Options, or use HCM's Native template editor page. Select a category, template and difficulty or event variant, then open a field group. The four tabs are Parameters, Composition & weights, Trigger conditions and Preset library.**

- Parameters: edit supported numbers, ranges, booleans and options. See the native baseline and the value with your HCM/HED changes.
- Composition & weights: edit eligible breeds, batch minimum/maximum counts and native selection weights. Native faction aliases and repeated pool entries retain their meaning.
- Trigger conditions: attach rules to supported encounter entry points or coordinated-horde predicate lists.
- Map population includes an optional map seed. Zero follows the mission seed; a chosen seed does not make the whole mission deterministic.

Categories cover combat pacing and heat, map population, hordes and trickle waves, specialists, monsters and patrols, automatic combat events, condition mechanics and supported mission combat nodes. The available fields follow the current game's templates; selecting a template does not activate that source in your mission.

Click a number to type or paste. Enter or clicking elsewhere confirms; Esc cancels. Hold + or − to repeat. Remove override follows HCM again; Override with native value pins the original field value. The preset library also offers a two-click reset of all HED edits and the map seed, retaining HCM values and saved files.

## Trigger rules

Combine up to eight clauses using All or Any. Conditions cover capable-player count, pacing stage, combat load, active monsters/events/hordes, low coherency, main-path progress, time without forward progress, low-pressure duration and engaged ranged formations.

New-encounter rules add requirements to native eligibility. Only supported coordinated-horde predicate lists offer replacement. Native placement limits and mission progression still apply. Gating an event delays its first spawn; an event that has already started can finish normally.

## Interaction with HCM

HCM applies broad changes first; HED overrides individual fields afterward. Native difficulty, selected conditions and runtime scheduling can then modify those values. For mission combat nodes, the displayed budget is the base value: HCM's event-budget multiplier scales the final native budget and its cap.

Settings save automatically and apply next mission. The running mission retains its initial configuration. DMF switches apply immediately in the hub and are deferred during play. HCM can run alone when HED is disabled.

This editor replaces the previous custom-generator design. Old generator presets remain on disk and are reported as unsupported; they cannot be loaded as native-template presets. Custom spawn queues, derived total caps and the former Buff event-capacity control are no longer part of HED; those systems use game behavior.

## Preset library

Presets store HCM multipliers, HED field overrides, trigger rules and the optional map seed. Mission, condition, faction and environment choices remain saved by SoloPlay. A preset stores changes, while native template data is read from the installed game.

Folder: %APPDATA%/Fatshark/Darktide/HavocEnemyDirector/templates

- Save under a name of up to 64 characters. Existing files require overwrite confirmation.
- Select a file, review its summary and load it for the next mission.
- Share a JSON file or copy share data. Import from the clipboard, or place a file in the folder and refresh. Importing does not automatically load it.
- Delete only after confirming the displayed name and filename. Cancel or Esc keeps the file; deletion does not reset the loaded setup.

Files are limited to 256 KiB. Invalid fields, incompatible breeds, unsupported formats and unknown template IDs are rejected. Presets contain data rather than executable Lua. The folder is separate from the mod installation.

## Requirements and compatibility

Requires Darktide Mod Loader, Darktide Mod Framework, SoloPlay and a compatible Havoc Condition Manager with the native template editor API. Realms is optional for co-op; the local host controls gameplay settings. English, Simplified Chinese and Traditional Chinese follow the game language. Native identifiers remain visible to distinguish exact templates and fields.

Large populations and frequent encounters increase game workload. Other mods replacing the same templates or scheduling methods may conflict. Mission objectives, named actors and unsupported function-driven fields are not exposed as editable controls.

## Vortex installation

- Close the game and install the requirements. Import this ZIP with Install From File, enable it and select Deploy Mods.
- Use Load Order: SoloPlay → HavocConditionManager → HavocEnemyDirector.
- Restart the game and open Havoc Enemy Director from Mod Options.

## Manual installation

- Close the game. When upgrading, remove the previous HavocEnemyDirector installation folder before extracting the new ZIP. Saved settings and preset files are stored separately.
- Extract into Darktide/mods, producing mods/HavocEnemyDirector.
- Add HavocEnemyDirector after HavocConditionManager in mods/mod_load_order.txt, with SoloPlay before both.
- Restart the game and open Havoc Enemy Director in Mod Options.

## Credits

SoloPlay: deluxghost. Native game systems and assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code.
