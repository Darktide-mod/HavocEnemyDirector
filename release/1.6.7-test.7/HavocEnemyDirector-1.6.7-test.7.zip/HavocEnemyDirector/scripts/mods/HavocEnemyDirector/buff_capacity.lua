local mod=get_mod("HavocEnemyDirector")
local base=get_mod("HavocConditionManager")
local native_capacity=require("scripts/settings/buff/buff_settings").max_proc_events
local session_capacity

mod.get_buff_proc_capacity=function()
    return math.floor(mod.planner.number(mod:get("buff_proc_capacity"),native_capacity,native_capacity,3000))
end
mod.set_buff_proc_capacity=function(value)
    mod:set("buff_proc_capacity",math.floor(mod.planner.number(value,native_capacity,native_capacity,3000)))
end
mod.get_session_buff_proc_capacity=function()
    if not session_capacity then session_capacity=mod.get_buff_proc_capacity() end
    return session_capacity
end
mod.reset_buff_proc_capacity=function() session_capacity=nil end

-- PERF_DEBUG_BEGIN
local function report(self,t,final)
    local pool=self._hed_proc_pool
    if not pool or pool.peak<=native_capacity and pool.dropped==0 then return end
    if not final and ((t or 0)<(pool.next_report or 0) or
        pool.reported_dropped==pool.dropped and pool.reported_processed==pool.processed) then return end
    local log=pool.dropped>(pool.reported_dropped or 0) and mod.warning or mod.info
    log(mod,"Proc capacity (%s): unit=%s kind=%s capacity=%d peak=%d dropped=%d",
        final and "destroy" or "periodic",tostring(self._unit),pool.owner_kind,pool.capacity,pool.peak,pool.dropped)
    if pool.events and pool.samples>0 then
        local names,parts={},{}
        for name in pairs(pool.events) do names[#names+1]=name end
        table.sort(names,function(a,b)
            if pool.events[a]==pool.events[b] then return a<b end
            return pool.events[a]>pool.events[b]
        end)
        for i=1,math.min(5,#names) do
            local name=names[i]; parts[#parts+1]=name.."="..pool.events[name]
        end
        mod:info("Proc workload: unit=%s processed=%d sampled_batches=%d sampled_events=%d top_events=%s",
            tostring(self._unit),pool.processed,pool.samples,pool.sampled_events,table.concat(parts,","))
        pool.samples=0; pool.sampled_events=0; table.clear(pool.events)
    end
    pool.next_report=(t or 0)+30
    pool.reported_dropped,pool.reported_processed=pool.dropped,pool.processed
end
-- PERF_DEBUG_END

mod:hook_require("scripts/extension_systems/buff/buff_extension_base",function(BuffExtensionBase)
    mod._capacity_buff_classes=mod._capacity_buff_classes or setmetatable({},{__mode="k"})
    if mod._capacity_buff_classes[BuffExtensionBase] then return end
    mod._capacity_buff_classes[BuffExtensionBase]=true
    mod:hook(BuffExtensionBase,"init",function(func,self,context,unit,data,...)
        self._hed_proc_pool=nil
        -- HED owns this setting independently of native/advanced spawn mode.
        -- Establish the fixed ring before native init can enqueue initial Buffs.
        if context.is_server and mod.is_gameplay_enabled() and base.has_local_gameplay_authority() then
            local capacity=mod.get_session_buff_proc_capacity()
            if capacity~=native_capacity then
                self._hed_proc_pool={capacity=capacity}
-- PERF_DEBUG_BEGIN
                local pool=self._hed_proc_pool
                pool.peak=0;pool.dropped=0;pool.processed=0
                pool.owner_kind=data.player and "player" or "unit"
                pool.next_sample=0;pool.samples=0;pool.sampled_events=0
-- PERF_DEBUG_END
            end
        end
        return func(self,context,unit,data,...)
    end)
    mod:hook(BuffExtensionBase,"request_proc_event_param_table",function(func,self)
        local pool=self._hed_proc_pool
        if not pool then return func(self) end
        local requested=self._num_params_table_in_use+1
        if requested>pool.capacity then
-- PERF_DEBUG_BEGIN
            pool.dropped=pool.dropped+1
-- PERF_DEBUG_END
            return nil
        end
        local index=(self._param_tables_start_index_reference+requested-2)%pool.capacity+1
        local params=self._proc_event_param_tables[index]
        if not params then params=Script.new_map(32); self._proc_event_param_tables[index]=params end
        self._num_params_table_in_use=requested
-- PERF_DEBUG_BEGIN
        pool.peak=math.max(pool.peak,requested)
-- PERF_DEBUG_END
        return params
    end)
    mod:hook(BuffExtensionBase,"_clear_param_tables",function(func,self,count)
        local pool=self._hed_proc_pool
        if not pool then return func(self,count) end
-- PERF_DEBUG_BEGIN
        local diagnostic=pool.peak>native_capacity or pool.dropped>0
        local time=diagnostic and Managers.time
        local t=time and time:time("gameplay") or 0
        local sample=pool.owner_kind=="player" and pool.peak>native_capacity and count>0 and t>=pool.next_sample
        pool.processed=pool.processed+count
        if sample then
            pool.next_sample=t+5; pool.samples=pool.samples+1; pool.events=pool.events or {}
        end
-- PERF_DEBUG_END
        local index=self._param_tables_start_index_reference
        for i=1,count do
            local params=self._proc_event_param_tables[index]
-- PERF_DEBUG_BEGIN
            if sample then
                local event=params.triggering_proc_event
                if type(event)=="string" then
                    pool.events[event]=(pool.events[event] or 0)+1
                    pool.sampled_events=pool.sampled_events+1
                end
            end
-- PERF_DEBUG_END
            table.clear(params)
            index=index+1
            if index>pool.capacity then index=1 end
        end
        self._param_tables_start_index_reference=index
-- PERF_DEBUG_BEGIN
        if diagnostic then report(self,t,false) end
-- PERF_DEBUG_END
    end)
-- PERF_DEBUG_BEGIN
    mod:hook_safe(BuffExtensionBase,"destroy",function(self) report(self,nil,true) end)
-- PERF_DEBUG_END
end)
