local mod = get_mod("HavocEnemyDirector")
local base = get_mod("HavocConditionManager")
local P = mod.planner
-- PERF_DEBUG_BEGIN
local S = mod.capacity_stats
-- PERF_DEBUG_END
-- PERF_DEBUG_BEGIN
local Perf = mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/performance_stats")
-- PERF_DEBUG_END
local Population = mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/population")
local Cleanup = mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/special_cleanup")
local M = base:io_dofile("HavocConditionManager/scripts/mods/HavocConditionManager/spawn_scaling")
local Breeds = require("scripts/settings/breed/breeds")
local Circumstances = require("scripts/settings/circumstance/circumstance_templates")
local Mutators = require("scripts/settings/mutator/mutator_templates")
local PacingTemplates = require("scripts/managers/pacing/pacing_templates")
local HordePacingTemplates = require("scripts/managers/pacing/horde_pacing/horde_pacing_templates")
local PacingManager = require("scripts/managers/pacing/pacing_manager")
local HordePacing = require("scripts/managers/pacing/horde_pacing/horde_pacing")
local HordeManager = require("scripts/managers/horde/horde_manager")
local SpecialsPacing = require("scripts/managers/pacing/specials_pacing/specials_pacing")
mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/native_specials")(mod,SpecialsPacing)
local HeatPacing = require("scripts/managers/pacing/heat_pacing/heat_pacing")
local MonsterPacing = require("scripts/managers/pacing/monster_pacing/monster_pacing")
local RoamerPacing = require("scripts/managers/pacing/roamer_pacing/roamer_pacing")
local MinionSpawnManager = require("scripts/managers/minion/minion_spawn_manager")
local MutatorSpawner = require("scripts/managers/mutator/mutators/mutator_spawner")
local NurgleWarp = require("scripts/managers/mutator/mutators/mutator_nurgle_warp")
local PlayerUnitStatus = require("scripts/utilities/attack/player_unit_status")
-- Record the running game's own data, so source-version differences are visible.
local armor_mutator=Mutators.mutator_live_rotten_armor_trickle_horde
local armor=armor_mutator and armor_mutator.trickle_horde_templates and armor_mutator.trickle_horde_templates[1]
if armor then
    mod:info("Native rotten armor: min_players=%s, travel=%s-%s, active_hordes_for_cooldown=%s, cooldown=%s-%s",
        tostring(armor.min_players_alive),tostring(armor.trickle_horde_travel_distance_range[1]),tostring(armor.trickle_horde_travel_distance_range[2]),
        tostring(armor.num_trickle_hordes_active_for_cooldown),tostring(armor.trickle_horde_cooldown[1]),tostring(armor.trickle_horde_cooldown[2]))
end
-- Inspect only the three definitions absent from the public Lua checkout.
-- Missing source is not evidence that a condition changes spawn rates.
for _,id in ipairs({"mutator_duplicating_enemies","mutator_armored_bombers","mutator_havoc_thorny_armor"}) do
    local t=Mutators[id]
    if type(t)=="table" then
        local keys,buffs={},{}
        for key in pairs(t) do keys[#keys+1]=tostring(key) end
        table.sort(keys)
        local direct=type(t.buff_templates)=="table" and t.buff_templates or {}
        local random=type(t.random_spawn_buff_templates)=="table" and t.random_spawn_buff_templates or {}
        for _,name in ipairs(direct) do buffs[#buffs+1]=tostring(name) end
        for _,name in ipairs(type(random.buffs)=="table" and random.buffs or {}) do buffs[#buffs+1]=tostring(name) end
        mod:info("Native condition audit %s: class=%s; fields=%s; buffs=%s",id,tostring(t.class),table.concat(keys,","),table.concat(buffs,","))
    end
end
mod.breeds, mod.category_for = Breeds, M.category_for_breed
local Queue=mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/spawn_queue")
local runtime
local session_scaling
-- PERF_DEBUG_BEGIN
local function runtime_log(...) mod:info(...) end
-- PERF_DEBUG_END
mod.get_spawn_scaling=function()
    local scaling={}
    for _,category in ipairs(P.categories) do
        local multiplier=M.normalize(base:get(M.setting_ids[category]))
        local mode=base:get("spawn_mode_"..category) or "quantity"
        local speed,quantity=M.factors(multiplier,mode)
        scaling[category]={multiplier=multiplier,mode=mode,speed=speed,quantity=quantity}
    end
    return scaling
end
mod.get_session_scaling=function()
    if not session_scaling then session_scaling=mod.get_spawn_scaling() end
    return session_scaling
end

local function local_havoc()
    local difficulty=Managers.state and Managers.state.difficulty
    return mod.is_gameplay_enabled() and base.has_local_gameplay_authority() and difficulty and type(difficulty:get_parsed_havoc_data())=="table"
end
mod.is_active=function()
    if not local_havoc() then return false end
    if runtime and runtime.pacing~=Managers.state.pacing then mod.reset_runtime() end
    return runtime and runtime.cfg.enabled or not runtime and mod.peek_config().enabled
end
local function resolve(name)
    local pacing=Managers.state and Managers.state.pacing
    local specials=pacing and pacing._specials_pacing
    if specials and specials._template then name=specials:_get_breed_name(name) end
    local spawner=Managers.state and Managers.state.minion_spawn
    if spawner then name=spawner:replacement_breed(name) or name end
    return name
end
mod.resolve_breed=resolve
local function mean(value,default)
    if type(value)=="number" then return value end
    if type(value)=="table" and type(value[1])=="number" then return (value[1]+(value[2] or value[1]))/2 end
    return default
end
local function tier(value)
    if type(value)~="table" then return value end
    local d=Managers.state and Managers.state.difficulty
    return d and d:get_table_entry_by_resistance(value) or value[math.min(5,#value)]
end
local function challenge(value)
    if type(value)~="table" then return value end
    local d=Managers.state and Managers.state.difficulty
    return d and d:get_table_entry_by_challenge(value) or value[math.min(5,#value)]
end
local preview_tiers={1,2,3,4,5,6}
-- Only the editor uses this key. Runtime source collection still reads the
-- live pacing, mutators and pools on its original schedule.
mod.preview_context_key=function()
    local solo=get_mod("SoloPlay")
    return table.concat({
        table.concat(base.get_selected_conditions(), ":"), -- preserve override order
        tostring(solo and solo:get("havoc_faction")),
        tostring(tier(preview_tiers)), tostring(challenge(preview_tiers)),
        tostring(base:get("monster_specials_melee_twin_captain")),
        tostring(base:get("monster_specials_ranged_twin_captain")),
        tostring(base:get("monster_specials_houndmaster")),
    }, "|")
end
mod.collect_sources=function(preview)
    local templates,ids,modify,replacements={},{},{},{}
    local function include(id,t)
        if t and not templates[id] then templates[id]=t; ids[#ids+1]=id end
    end
    local difficulty=Managers.state and Managers.state.difficulty
    local havoc=not preview and difficulty and difficulty:get_parsed_havoc_data()
    local live=not preview and Managers.state.mutator and Managers.state.mutator._mutators
    -- Match native circumstance load order. Alphabetical mutator order changes
    -- last-writer overrides and can disagree with the actual mission.
    for _,id in ipairs(havoc and havoc.circumstances or base.get_selected_conditions()) do
        for _,name in ipairs(Circumstances[id] and Circumstances[id].mutators or {}) do
            include(name,live and live[name] and live[name]._template or not live and Mutators[name])
        end
    end
    if live then
        local extra={}
        for id in pairs(live) do if not templates[id] then extra[#extra+1]=id end end
        table.sort(extra)
        for _,id in ipairs(extra) do include(id,live[id]._template) end
    end
    for _,field in ipairs({"init_modify_pacing","modify_pacing"}) do
        for _,id in ipairs(ids) do
            local t=templates[id]
            for key,value in pairs(t[field] or {}) do modify[key]=value end
        end
    end
    for _,id in ipairs(ids) do
        local t=templates[id]
        for name,replacement in pairs(t.init_replacement_breed and t.init_replacement_breed.breed_replacement or {}) do
            replacements[name]=replacement
        end
    end
    local function selected_resolve(name)
        local visited={}
        while type(replacements[name])=="string" and not visited[name] do
            visited[name]=true; name=replacements[name]
        end
        return name
    end
    local resolve=preview and selected_resolve or resolve
    if preview then mod.preview_resolve=selected_resolve end
    local pacing=not preview and Managers.state and Managers.state.pacing
    for key,value in pairs(pacing and pacing._hed_applied_modifiers or {}) do modify[key]=value end
    local roamer=pacing and pacing._roamer_pacing
    local solo=get_mod("SoloPlay")
    local faction=roamer and roamer._override_faction or modify.override_faction
        or preview and solo and solo:get("havoc_faction") or havoc and havoc.faction
    if faction~="renegade" and faction~="cultist" then faction=nil end
    local function faction_composition(value,seen)
        if type(value)~="table" then return value end
        seen=seen or {}
        if seen[value] then return seen[value] end
        if faction and value[faction] then
            local result=faction_composition(value[faction],seen)
            seen[value]=result
            return result
        end
        local result={}
        seen[value]=result
        for key,child in pairs(value) do result[key]=type(child)=="table" and faction_composition(child,seen) or child end
        return result
    end
    local template=pacing and pacing._template or PacingTemplates.havoc
    local hp=pacing and pacing._horde_pacing
    local sp=pacing and pacing._specials_pacing
    local mp=pacing and pacing._monster_pacing
    local horde=hp and hp._template or tier(template.horde_pacing_template.resistance_templates)
    -- Native pacing replaces its horde template; it does not add a second
    -- independent horde stream. The live _template already has this override.
    if not hp then
        for _,id in ipairs(ids) do
            local t=templates[id]
            if t.pacing_override and t.template_name then
                local family=HordePacingTemplates[t.template_name]
                horde=family and family.resistance_templates[t.pacing_override] or horde
            end
        end
    end
    local specials=sp and sp._template or tier(template.specials_pacing_template.resistance_templates)
    local monster_tiers=template.monster_pacing_template.challenge_templates
    local monsters=mp and mp._template or difficulty and difficulty:get_table_entry_by_challenge(monster_tiers) or monster_tiers[math.min(5,#monster_tiers)]
    local sources,seen={faction=faction,forced_boss_patrols=modify.boss_patrols_per_travel_distance~=nil or
        type(modify.num_boss_patrol_override)=="number" and modify.num_boss_patrol_override>0},{}
    local function add(id,kind,composition,interval,distance)
        sources[#sources+1]={id=id,kind=kind,composition=composition,interval=interval,distance=distance}
    end
    local function trickle(id,tr)
        if seen[tr] then return end
        seen[tr]=true
        local waves=mean(challenge(tr.num_trickle_waves),1)
        -- Cooldown is conditional on active hordes, not an unconditional
        -- respawn interval. Average the actual wave duration for this director.
        local duration=mean(tr.stinger_duration,0)+math.max(0,waves-1)*mean(tr.time_between_waves,10)
        local composition={trickle_horde=P.copy(tr.horde_compositions.trickle_horde)}
        local override=hp and hp._override_trickle_horde_compositions or modify.override_trickle_horde_compositions
        if override then composition.trickle_horde=override end
        local skip_heat=tr.optional_mutator_params and tr.optional_mutator_params.skip_heat_override
        add(id,"travel",faction_composition(composition),math.max(1,duration/math.max(waves,1)),mean(not skip_heat and hp and hp._trickle_travel_distance_modifer or tr.trickle_horde_travel_distance_range,100)/math.max(waves,1))
        local pause=tr.pause_pacing_on_spawn
        if pause and pause[1] then pause=challenge(pause) end
        local source=sources[#sources]
        source.spawn_type="trickle_hordes"
        source.tier=tier({1,2,3,4,5,6})
        source.rules={min_players=tr.min_players_alive,not_during_events=tr.not_during_terror_events,
            active_limit=not skip_heat and hp and hp._num_trickle_hordes_active_for_cooldown_modifer or tr.num_trickle_hordes_active_for_cooldown,
            cooldown=mean(not skip_heat and hp and hp._trickle_horde_cooldown_modifer or tr.trickle_horde_cooldown,0),pause=P.copy(pause)}
        source.profile=P.rules_key(source.rules)
    end
    local roamer_template=roamer and roamer._roamer_template or template.roamer_pacing_template
    local density=tier(roamer_template.density_settings)
    local packs={}
    for _,density_type in ipairs(roamer_template.density_types or {"low","high"}) do
        local setting=density[density_type]
        if setting then
            packs[density_type]=roamer and roamer._all_pack_override or modify.override_all_roamer_packs
                or (roamer and roamer._packs_override or modify.override_roamer_packs or {})[density_type] or setting.packs
        end
    end
    add("native_roamers","ambient",faction_composition(packs),60)
    if horde then
        -- _setup_next_horde selects only horde_templates. Trickle, flood and
        -- coordinated-strike tables are not interchangeable timer alternatives.
        local pool={}
        local choices=horde.horde_templates or {}
        local interval=mean(horde.horde_timer_range,90)*(hp and hp._timer_modifier or mean(modify.horde_timer_modifier,1))
        for _,choice in ipairs(choices) do
            local name=choice.name
            local waves=mean(horde.num_waves and horde.num_waves[name],1)
            local duration=interval+math.max(0,waves-1)*mean(horde.time_between_waves,0)
            local composition=P.collect(faction_composition(horde.horde_compositions[name]),Breeds,resolve,challenge({1,2,3,4,5,6}))
            for breed,amount in pairs(composition) do pool[breed]=(pool[breed] or 0)+amount*waves*interval/duration/#choices end
        end
        sources[#sources+1]={id="native_hordes",spawn_type="hordes",kind="timer",pool=pool,interval=interval}
        sources[#sources].rules={horde_travel=hp and hp._override_required_travel_distance or modify.required_horde_travel_distance or mean(horde.travel_distance_required_for_horde,0)}
        if horde.horde_compositions.trickle_horde then trickle("native_trickles",horde) end
    end
    if specials and specials.breeds then
        local pool={}
        for _,name in ipairs(specials.breeds.all) do
            local variants=specials.faction_bound_breeds and specials.faction_bound_breeds[name]
            local candidates=variants and (faction and {variants[faction]} or {variants.cultist,variants.renegade}) or {name}
            for _,candidate in ipairs(candidates) do
                candidate=resolve(candidate)
                if Breeds[candidate] then pool[candidate]=(pool[candidate] or 0)+1/#candidates end
            end
        end
        local slots=sp and sp._max_alive_specials or math.ceil(mean(specials.max_alive_specials,6)*mean(challenge(modify.max_alive_specials_multiplier),1))
        for name,weight in pairs(pool) do pool[name]=weight*slots/math.max(1,#specials.breeds.all) end
        local travel_specials=templates.mutator_travel_distance_spawning_specials
        local period=mean(specials.timer_range,30)*(sp and sp._timer_modifier or mean(modify.specials_timer_modifier,1))
        sources[#sources+1]={id="native_specials",spawn_type="specials",kind=travel_specials and "travel" or "timer",pool=pool,
            interval=travel_specials and 1 or period,distance=travel_specials and period or nil,
            breed_caps=P.copy(sp and sp._optional_max_of_same_override or modify.max_of_same_override),
            rules={required_challenge=sp and sp._required_challenge_rating or challenge(modify.specials_required_challenge_rating),
                special_travel=travel_specials~=nil,
                move_timer_for_monster=templates.mutator_move_specials_timer_when_monster_active~=nil}}
    end
    if monsters and modify.num_monsters_override~=0 then
        add("native_monsters",monsters.pacing_type=="timer_based" and "timer" or "travel",
            monsters.breed_names and monsters.breed_names.monsters,
            mean(monsters.monster_timer_range,180),monsters.pacing_type~="timer_based" and 600 or nil)
        local source=sources[#sources]
        source.pool=P.collect(source.composition,Breeds,resolve)
        local n=math.max(1,#(monsters.breed_names and monsters.breed_names.monsters or {}))
        for name,amount in pairs(source.pool) do source.pool[name]=amount/n end
        local health=mp and mp._health_modifier or modify.monster_health_modifier
        if health then
            source.health_modifiers={}
            for name in pairs(source.pool) do source.health_modifiers[name]=health end
        end
    end
    if templates.mutator_no_hordes then
        for i=#sources,1,-1 do if sources[i].id=="native_hordes" then table.remove(sources,i) end end
    end
    local travel_overrides={}
    local weak_config=sp and sp._monster_spawn_config or modify.specials_monster_spawn_config or specials and specials.default_monster_spawn_config
    for _,id in ipairs(ids) do
        local t=templates[id]
        if t then
            for index,tr in ipairs(t.trickle_horde_templates or {}) do trickle(id..":"..index,tr) end
            if t.class=="scripts/managers/mutator/mutators/mutator_nurgle_warp" then add(id,"event",t.compositions,1) end
            local modify=P.copy(t.init_modify_pacing or {})
            for key,value in pairs(t.modify_pacing or {}) do modify[key]=value end
            if modify and modify.monsters_per_travel_distance and modify.monster_breed_name then
                local name=modify.monster_breed_name
                if name=="MUTATOR_CAPTAIN" then name="renegade_captain" end
                if type(name)=="table" then
                    name=P.copy(name)
                    for i,value in ipairs(name) do if value=="MUTATOR_CAPTAIN" then name[i]="renegade_captain" end end
                end
                travel_overrides[modify.monster_spawn_type or "monsters"]={id=id,names=type(name)=="table" and name or {name},distance=mean(modify.monsters_per_travel_distance,120)}
            end
        end
    end
    -- Native fill_spawns_by_travel_distance replaces the same spawn type.
    -- Its breed list chooses ONE candidate per placement, not the whole list.
    for _,spawn_type in ipairs({"monsters","witches","captains"}) do
        local entry=travel_overrides[spawn_type]
        if entry then
            if spawn_type=="monsters" then
                for i=#sources,1,-1 do if sources[i].id=="native_monsters" then table.remove(sources,i) end end
            end
            local pool=P.collect(entry.names,Breeds,resolve)
            for name,weight in pairs(pool) do pool[name]=weight/math.max(1,#entry.names) end
            sources[#sources+1]={id=entry.id,kind="travel",pool=pool,interval=120,distance=entry.distance}
        end
    end
    local function add_weak(id,config,profile,probability)
        local chance=config and config.chance_to_spawn_monster or 0
        if chance<=0 or probability and probability<=0 or not config.breeds then return end
        local pool=P.collect(config.breeds,Breeds,resolve)
        for name,weight in pairs(pool) do pool[name]=weight/math.max(1,#config.breeds) end
        local slots=sp and sp._max_alive_specials or math.ceil(mean(specials and specials.max_alive_specials,6)*mean(challenge(modify.max_alive_specials_multiplier),1))
        sources[#sources+1]={id=id,kind="timer",spawn_type="specials",profile=profile or "weak",pool=pool,cap=config.max_monsters,
            health_modifiers=P.copy(config.health_modifiers),
            interval=mean(specials and specials.timer_range,30)*(sp and sp._timer_modifier or mean(modify.specials_timer_modifier,1))/math.max(1,slots)/(chance*(probability or 1))}
    end
    if hp then
        for i,tr in ipairs(hp._hed_trickles or {}) do trickle("registered:"..i,tr) end
        for i,tr in ipairs(hp._trickle_hordes or {}) do trickle("runtime:"..i,tr.template) end
    end
    if weak_config then add_weak("native_monster_specials",weak_config) end
    if templates.more_havoc_monster_specials then
        -- Reference roll runs only after a failed native roll, with its own cap.
        add_weak("more_havoc_monster_specials",base.get_director_monster_specials_config(),"weak_reference",1-(weak_config and weak_config.chance_to_spawn_monster or 0))
    end
    local chance=weak_config and weak_config.chance_to_spawn_monster or 0
    if templates.more_havoc_monster_specials then chance=chance+(1-chance)*base.get_director_monster_specials_config().chance_to_spawn_monster end
    for _,source in ipairs(sources) do
        if source.id=="native_specials" then
            for name,weight in pairs(source.pool) do source.pool[name]=weight*(1-chance) end
        end
    end
    -- Resolve new-selection replacements before grouping, without reading the previous mission.
    if preview then
        for _,source in ipairs(sources) do
            if not source.pool then source.pool=P.collect(source.composition,Breeds,selected_resolve,source.tier) end
        end
    end
    return sources
end
mod.preview_generators=function()
    local sources=mod.collect_sources(true)
    return P.compile(sources,mod.get_config(),Breeds,M.category_for_breed,mod.preview_resolve)
end
local function session_faction()
    if runtime and runtime.sources then return runtime.sources.faction end
    local pacing=Managers.state and Managers.state.pacing
    local roamer=pacing and pacing._roamer_pacing
    return roamer and roamer._override_faction
end
local function allowed_breed(name)
    return P.faction_allowed(Breeds[resolve(name)],session_faction())
end

local function counts(refresh)
    local manager=Managers.state.minion_spawn
    local population=runtime.population
    if refresh or not population.ready or runtime.clock-(population.refreshed_at or 0)>=0.25 then
        local live_units=manager:spawned_minions()
-- PERF_DEBUG_BEGIN
        local population_started=Perf.begin(runtime.performance,"population",runtime.clock)
-- PERF_DEBUG_END
-- PERF_DEBUG_BEGIN
        Perf.count(runtime.performance,"population_scans")
-- PERF_DEBUG_END
-- PERF_DEBUG_BEGIN
        Perf.count(runtime.performance,"population_visits",#live_units)
-- PERF_DEBUG_END
        population:refresh(live_units,HEALTH_ALIVE,runtime.units)
-- PERF_DEBUG_BEGIN
        Perf.finish(runtime.performance,"population",population_started)
-- PERF_DEBUG_END
        population.refreshed_at=runtime.clock
    end
    return math.max(population.total,manager:total_allocated_num_enemies()),population.categories,population.generators
end
local function emit(generator,amount,job)
    local composition={breeds={}}
    local amounts={}
    local pool=generator._pool_sampler
    if generator.breed_caps then
        pool=P.copy(pool)
        local alive=runtime.population.breeds
        for name,cap in pairs(generator.breed_caps) do
            if (alive[name] or 0)>=cap then
                P.exclude_from_pool(pool,name)
-- PERF_DEBUG_BEGIN
                S.check(runtime.stats,"breed:"..name,alive[name] or 0,cap)
-- PERF_DEBUG_END
            end
        end
        amounts._alive=alive
    end
    for _=1,amount do
        local name=P.pick_prepared(pool)
        if not name then break end
        amounts[name]=(amounts[name] or 0)+1
        if generator.breed_caps and generator.breed_caps[name] and amounts[name]+(amounts._alive[name] or 0)>=generator.breed_caps[name] then P.exclude_from_pool(pool,name) end
    end
    amounts._alive=nil
    local names={}
    for name in pairs(amounts) do names[#names+1]=name end
    if #names==0 then return 0 end
    table.sort(names)
    for _,name in ipairs(names) do composition.breeds[#composition.breeds+1]={name=name,amount={amounts[name],amounts[name]}} end
    mod._emitted_count=0
    mod._spawning_generator=generator.id
    mod._spawning_health=generator.health
-- PERF_DEBUG_BEGIN
    local spawn_started=Perf.begin(runtime.performance,"spawn",runtime.clock)
-- PERF_DEBUG_END
    local ok,success=xpcall(function()
        return Managers.state.horde:horde("trickle_horde","trickle_horde",2,1,composition,true,35,6)
    end,function(err) return debug.traceback(tostring(err),2) end)
    mod._spawning_generator=nil
    mod._spawning_health=nil
-- PERF_DEBUG_BEGIN
    Perf.finish(runtime.performance,"spawn",spawn_started)
-- PERF_DEBUG_END
    local actual=mod._emitted_count or 0
    mod._emitted_count=nil
    if not ok then error(success,0) end
    -- A logical batch may create several native groups. Retain its identity
    -- without retaining temporary engine vectors or an extra global registry.
    local hordes=Managers.state.horde._hordes
    local trickles=hordes and hordes.trickle_horde
    if success and trickles and job and trickles[#trickles] then trickles[#trickles]._hed_batch_id=job.id end
    return actual
end
local function source_allowed(generator,next_at,clock,job)
    local rules=generator.rules
    if not rules then return true end
    local pacing=Managers.state.pacing
    if rules.required_challenge and pacing.total_challenge_rating and pacing:total_challenge_rating()<=rules.required_challenge then return false end
    if rules.horde_travel and rules.horde_travel>0 then
        if math.ceil((pacing:get_mission_progression() or 0)/(rules.horde_travel/(generator.speed or 1)))<=(next_at.hordes or 0) then return false end
    end
    if rules.not_during_events and Managers.state.terror_event:num_active_events()>0 then return false end
    if rules.active_limit and Managers.state.horde.num_active_hordes then
        local manager=Managers.state.horde
        local active=manager:num_active_hordes("trickle_horde")
        local hordes=manager._hordes and manager._hordes.trickle_horde
        if hordes then
            local seen={}; active=0
            for _,horde in ipairs(hordes) do
                local id=horde._hed_batch_id
                if not id then active=active+1
                elseif not seen[id] and (not job or id~=job.id) then active=active+1; seen[id]=true end
            end
        end
        if active>=rules.active_limit then
            next_at.cooldown=next_at.cooldown and clock<next_at.cooldown and next_at.cooldown or clock+rules.cooldown
            return false
        end
        next_at.cooldown=nil
    end
    if rules.min_players then
        local extension=Managers.state.extension
        local side=extension and extension:system("side_system"):get_side(1)
        local alive=0
        for _,unit in ipairs(side and side.valid_player_units or {}) do
            local data=ScriptUnit.extension(unit,"unit_data_system")
            if not PlayerUnitStatus.requires_help(data:read_component("character_state")) then alive=alive+1 end
        end
        if alive<rules.min_players then return false end
    end
    return true
end
mod.source_allowed=source_allowed
local function generation_allowed(generator,next_at,clock,job,source_checked)
    -- Admission has just checked source rules. Dispatch always checks afresh,
    -- because player, event, pressure and horde state can change while queued.
    if not source_checked and not source_allowed(generator,next_at,clock,job) then return false end
    for spawn_type in pairs(generator.spawn_types) do
        if not Managers.state.pacing:spawn_type_enabled(spawn_type) then return false end
    end
    return true
end
local function finish_job(job)
    local generator,next_at=job.generator,job.next_at
    local clock=runtime.clock
    if job.emitted>0 then
        next_at.hordes=(next_at.hordes or 0)+job.emitted/math.max(1,(generator.horde_amount or job.requested)*(generator.quantity or 1))
        next_at.remainder=job.remainder
        next_at.time=math.max(clock,next_at.time+generator.interval)
        next_at.distance=math.max(job.progression,next_at.distance+generator.distance)
        for spawn_type,duration in pairs(generator.rules and generator.rules.pause or {}) do
            runtime.pacing:pause_spawn_type(spawn_type,true,"trickle_horde",duration)
        end
    else next_at.time=clock+2 end
    if generator.kind=="event" then
        runtime.events[generator.category]=math.min(runtime.cfg.category_caps[generator.category],
            (runtime.events[generator.category] or 0)+job.remaining)
    end
end
local function drain_queue()
    if #runtime.queue.jobs==0 then return end
-- PERF_DEBUG_BEGIN
    local queue_started=Perf.begin(runtime.performance,"queue",runtime.clock)
-- PERF_DEBUG_END
    local frame_calls,frame_created,frame_requested=Queue.drain(runtime.queue,function(job,chunk)
        if not generation_allowed(job.generator,job.next_at,runtime.clock,job) then return 0 end
        local total,categories,generators=counts()
        local q,g=runtime.queue,job.generator
        return P.budget(g,runtime.cfg,total+q.total-job.remaining,
            (categories[g.category] or 0)+(q.categories[g.category] or 0)-job.remaining,
            (generators[g.id] or 0)+(q.generators[g.id] or 0)-job.remaining,chunk)
    end,emit,finish_job)
-- PERF_DEBUG_BEGIN
    Perf.count(runtime.performance,"native_calls",frame_calls)
-- PERF_DEBUG_END
-- PERF_DEBUG_BEGIN
    Perf.count(runtime.performance,"created",frame_created)
-- PERF_DEBUG_END
-- PERF_DEBUG_BEGIN
    Perf.peak(runtime.performance,"frame_requested",frame_requested)
-- PERF_DEBUG_END
-- PERF_DEBUG_BEGIN
    Perf.peak(runtime.performance,"pending_units",runtime.queue.total)
-- PERF_DEBUG_END
-- PERF_DEBUG_BEGIN
    Perf.finish(runtime.performance,"queue",queue_started)
-- PERF_DEBUG_END
end
mod.update_director=function(dt)
    if not local_havoc() then return end
    local pacing=Managers.state.pacing
    if not pacing or not pacing._horde_pacing._template or not pacing._specials_pacing._template then return end
    if not runtime or runtime.pacing~=pacing then
        if runtime then mod.reset_runtime() end
        local cfg,scaling=mod.get_config(),mod.get_session_scaling()
        runtime={pacing=pacing,cfg=cfg,scaling=scaling,elapsed=0,clock=0,units=setmetatable({},{__mode="k"}),events={},next={}}
        if runtime.cfg.enabled then
-- PERF_DEBUG_BEGIN
            runtime.stats=S.new()
            runtime.performance=Perf.new()
-- PERF_DEBUG_END
            runtime.population=Population.new(function(unit) return ScriptUnit.extension(unit,"unit_data_system"):breed() end,M.category_for_breed)
            runtime.cleanup=Cleanup.new()
            runtime.queue=Queue.new()
            runtime.ambient={}
            runtime.sources=mod.collect_sources(false)
            runtime.generators=P.compile(runtime.sources,cfg,Breeds,M.category_for_breed,resolve)
            runtime.tick=0.25
            for i,g in ipairs(runtime.generators) do
                local effective=P.effective(g,runtime.scaling)
                effective._pool_sampler=P.prepare_pool(effective.pool)
                runtime.generators[i]=effective
                if effective.kind=="ambient" then runtime.ambient[effective.id]=effective end
                if effective.enabled and effective.kind~="ambient" then runtime.tick=math.min(runtime.tick,effective.interval) end
            end
            mod:info("Compiled %d spawn sources into %d categorized generators; queue_clock=%s",#runtime.sources,#runtime.generators,Queue.clock_name)
            mod:info("Capacity config: total=%d common=%d elite=%d special=%d boss=%d; multipliers=%d/%d/%d/%d",
                runtime.cfg.total_cap,runtime.cfg.category_caps.common,runtime.cfg.category_caps.elite,
                runtime.cfg.category_caps.special,runtime.cfg.category_caps.boss,scaling.common.multiplier,scaling.elite.multiplier,scaling.special.multiplier,scaling.boss.multiplier)
            local scripted=runtime.cfg.generators.scripted_encounters
            mod:info("Session spawn switches: map_events=%s extra_spawns=%s havoc_twins=%s; revision=%s",
                tostring(not (scripted and scripted.deleted)),tostring(runtime.cfg.native_extras_enabled),
                tostring(runtime.cfg.havoc_twins_enabled),tostring(runtime.cfg.revision))
        else
            mod:info("Native generation selected: generators, pools, caps and extra-spawn switches remain native; HCM conditions and scaling apply")
        end
    end
    if not runtime.cfg.enabled then return end
    runtime.elapsed=runtime.elapsed+dt
    runtime.clock=runtime.clock+dt
    local path=Managers.state.main_path
    if path and path:is_main_path_available() then
-- PERF_DEBUG_BEGIN
        local started=Perf.begin(runtime.performance,"cleanup",runtime.clock)
-- PERF_DEBUG_END
        Cleanup.update(runtime.cleanup,pacing._specials_pacing,runtime.clock,HEALTH_ALIVE)
-- PERF_DEBUG_BEGIN
        Perf.finish(runtime.performance,"cleanup",started)
-- PERF_DEBUG_END
    end
    if runtime.elapsed<runtime.tick then
        if path and path:is_main_path_available() and path:ahead_unit(1) then drain_queue() end
        return
    end
-- PERF_DEBUG_BEGIN
    local sample_dt=runtime.elapsed-runtime.elapsed%runtime.tick
-- PERF_DEBUG_END
    runtime.elapsed=runtime.elapsed%runtime.tick
    if not path or not path:is_main_path_available() or not path:ahead_unit(1) then return end
-- PERF_DEBUG_BEGIN
    local started=Perf.begin(runtime.performance,"tick",runtime.clock)
-- PERF_DEBUG_END
    local travel=pacing:get_mission_progression() or 0
    local clock=runtime.clock
-- PERF_DEBUG_BEGIN
    local population=runtime.population
    -- An idle cached population is not a new measurement of time at capacity.
    if population.ready and runtime.clock-(population.refreshed_at or 0)<=0.250001 then
        S.observe(runtime.stats,sample_dt,population.total,population.categories,population.generators,runtime.cfg,runtime.generators)
    end
    runtime.stats.elapsed=runtime.clock
    S.report(runtime.stats,runtime_log)
-- PERF_DEBUG_END
    local total_generators=#runtime.generators
    local admission_start=runtime.admission_cursor or 1
    for offset=1,total_generators do
        local index=(admission_start+offset-2)%total_generators+1
        local generator=runtime.generators[index]
        local next_at=runtime.next[generator.id]
        if not next_at then
            next_at={time=clock+generator.interval,distance=travel+generator.distance}
            runtime.next[generator.id]=next_at
        end
        local progression=travel
        if generator.rules and generator.rules.special_travel then
            local elapsed=clock-(next_at.last_clock or clock)
            local delta=math.max(0,travel-(next_at.last_travel or travel))
            if generator.rules.move_timer_for_monster and pacing.num_aggroed_monsters and pacing:num_aggroed_monsters()>0 then delta=elapsed end
            next_at.progress=(next_at.progress or travel)+delta
            next_at.last_clock,next_at.last_travel=clock,travel
            progression=next_at.progress
        end
        local event_count=runtime.events[generator.category] or 0
        local due=generator.kind=="event" and event_count>0 and clock>=next_at.time
            or generator.kind=="timer" and clock>=next_at.time
            or generator.kind=="travel" and progression>=next_at.distance and clock>=next_at.time
        -- Travel accumulation above must run continuously. Source/player/event
        -- checks only matter when an enabled generator is actually due.
        local source_ready=true
        if generator.enabled and due and not runtime.queue.owners[generator.id] then source_ready=source_allowed(generator,next_at,clock) end
        if generator.enabled and due and source_ready and not runtime.queue.owners[generator.id] and generation_allowed(generator,next_at,clock,nil,true) then
            local requested,remainder=P.batch(generator,next_at.remainder)
            local budget_request=generator.kind=="event" and math.floor(math.min(requested,event_count)) or requested
            local total,by_category,by_generator=counts()
            local q=runtime.queue
            total=total+q.total
            local category_count=(by_category[generator.category] or 0)+(q.categories[generator.category] or 0)
            local generator_count=(by_generator[generator.id] or 0)+(q.generators[generator.id] or 0)
-- PERF_DEBUG_BEGIN
            S.budget(runtime.stats,generator,runtime.cfg,total,category_count,generator_count,budget_request)
-- PERF_DEBUG_END
            local amount=P.budget(generator,runtime.cfg,total,category_count,generator_count,budget_request)
            if amount>0 then
                runtime.batch_id=(runtime.batch_id or 0)+1
                Queue.add(q,{id=runtime.batch_id,generator=generator,next_at=next_at,remaining=amount,requested=amount,remainder=remainder,progression=progression})
                runtime.admission_cursor=index%total_generators+1
                if generator.kind=="event" then runtime.events[generator.category]=math.max(0,event_count-amount) end
            else next_at.time=clock+runtime.tick end
        elseif due and not source_ready and generator.kind=="travel" then
            next_at.distance=progression+generator.distance
        end
    end
-- PERF_DEBUG_BEGIN
    Perf.finish(runtime.performance,"tick",started)
-- PERF_DEBUG_END
    drain_queue()
-- PERF_DEBUG_BEGIN
    Perf.report(runtime.performance,runtime.clock,runtime_log)
-- PERF_DEBUG_END
end
mod.reset_runtime=function()
-- PERF_DEBUG_BEGIN
    if runtime and runtime.stats then S.report(runtime.stats,runtime_log,true) end
-- PERF_DEBUG_END
-- PERF_DEBUG_BEGIN
    if runtime and runtime.performance then Perf.report(runtime.performance,runtime.clock,runtime_log,true) end
-- PERF_DEBUG_END
    runtime=nil; session_scaling=nil; mod._spawning_generator=nil; mod._spawning_health=nil; mod._emitted_count=nil
end
mod:hook_safe(PacingManager,"update",function(self,dt)
    if Managers.state and self==Managers.state.pacing then mod.update_director(dt) end
end)
-- Preserve the actual order of post-init modifiers used by the running game.
mod:hook_safe(PacingManager,"add_pacing_modifiers",function(self,settings)
    if not mod.is_active() then return end
    self._hed_applied_modifiers=self._hed_applied_modifiers or {}
    for key,value in pairs(settings) do self._hed_applied_modifiers[key]=P.copy(value) end
end)
mod:hook(MinionSpawnManager,"spawn_minion",function(func,self,name,position,rotation,side,params)
    local health=mod._spawning_health and mod._spawning_health[name]
    if health then
        params=P.copy(params or {})
        params.optional_health_modifier=health
    end
    local unit=func(self,name,position,rotation,side,params)
    if unit and runtime and runtime.cfg.enabled and runtime.pacing==Managers.state.pacing then
        if mod._spawning_generator then
            runtime.units[unit]=mod._spawning_generator
            if mod._emitted_count then mod._emitted_count=mod._emitted_count+1 end
        end
        local entry=runtime.population:add(unit,runtime.units[unit],HEALTH_ALIVE)
        if entry and entry.category=="special" and runtime.units[unit] then Cleanup.add(runtime.cleanup,unit,runtime.clock) end
    end
    return unit
end)
mod:hook(MinionSpawnManager,"unregister_unit",function(func,self,unit,...)
    local removed=func(self,unit,...)
    if removed and runtime and runtime.cfg.enabled and self==Managers.state.minion_spawn then
        runtime.population:remove(unit)
        runtime.units[unit]=nil
        Cleanup.remove(runtime.cleanup,unit)
    end
    return removed
end)

mod:hook(HordePacing,"add_trickle_horde",function(func,self,template)
    if not mod.is_active() then return func(self,template) end
    self._hed_trickles=self._hed_trickles or {}
    self._hed_trickles[#self._hed_trickles+1]=template
end)
mod:hook(HordePacing,"_update_horde_pacing",function(func,self,...)
    if not mod.is_active() then return func(self,...) end
end)
mod:hook(HordePacing,"_update_trickle_horde_pacing",function(func,self,...)
    if not mod.is_active() then return func(self,...) end
end)
mod:hook(SpecialsPacing,"_spawn_special",function(func,self,slot,...)
    if not mod.is_active() then return func(self,slot,...) end
    if not slot.injected or not allowed_breed(slot.breed_name) or mod.get_session_config().banned[resolve(slot.breed_name)] then return false end
    return func(self,slot,...)
end)
-- Gate the producers, not try_inject_special: rush injections have no prevention
-- flag, while mutators, auto-events and mission scripts share that same API.
local function extra_injections(func,self,...)
    if mod.is_active() and mod.get_session_config().native_extras_enabled==false then return end
    return func(self,...)
end
for _,method in ipairs({"_update_rush_prevention","_update_loner_prevention","_update_speed_running_prevention"}) do
    mod:hook(SpecialsPacing,method,extra_injections)
end
mod:hook(HeatPacing,"_update_special_injection",extra_injections)
mod:hook(MonsterPacing,"_spawn_boss_patrol",function(func,self,...)
    if mod.is_active() and mod.get_session_config().native_extras_enabled==false then
        -- The selected condition can explicitly require this native patrol path.
        local sources=runtime and runtime.sources or mod.collect_sources(false)
        if not sources.forced_boss_patrols then return end
    end
    return func(self,...)
end)
mod:hook(MonsterPacing,"_spawn_monster",function(func,self,monster,...)
    if not mod.is_active() or not M.category_for_breed(Breeds[monster.breed_name]) then return func(self,monster,...) end
end)
mod:hook(MonsterPacing,"_fill_spawns_by_timer",function(func,self,...)
    if not mod.is_active() then return func(self,...) end
end)
mod:hook(NurgleWarp,"spawn_group",function(func,self,composition,unit)
    if not mod.is_active() or not runtime then return func(self,composition,unit) end
    local pool=P.collect(composition,Breeds,resolve)
    for name,amount in pairs(pool) do
        local category=M.category_for_breed(Breeds[name])
        if category then
            local quantity=runtime.scaling[category].quantity
            runtime.events[category]=math.min(runtime.cfg.category_caps[category],(runtime.events[category] or 0)+amount*quantity)
        end
    end
end)
mod.get_session_config=function() return runtime and runtime.cfg or mod.peek_config() end
mod:hook(PacingManager,"heat_trickle_should_patrol",function(func,self)
    if mod._spawning_generator then return false end
    return func(self)
end)
mod:hook(PacingManager,"spawn_type_enabled",function(func,self,spawn_type)
    if not mod.is_active() then return func(self,spawn_type) end
    local cfg=mod.get_session_config()
    if self._disabled and spawn_type~="terror_events" then return false,"pacing_is_disabled" end
    local allocated=Managers.state.minion_spawn:total_allocated_num_enemies()
    if allocated>=cfg.total_cap then
-- PERF_DEBUG_BEGIN
        if runtime and runtime.stats then S.check(runtime.stats,"total",allocated,cfg.total_cap) end
-- PERF_DEBUG_END
        return false,"Hard_allocated_limit_reached"
    end
    local threshold=self._challenge_rating_thresholds and self._challenge_rating_thresholds[spawn_type]
    if threshold and threshold<(self._total_challenge_rating or 0) then
-- PERF_DEBUG_BEGIN
        if runtime then Perf.count(runtime.performance,"pressure_blocks") end
-- PERF_DEBUG_END
        return false,"disabled_by_challenge_rating"
    end
    if self._paused_spawn_types[spawn_type] then return false,"paused" end
    if self._frozen_spawn_types and self._frozen_spawn_types[spawn_type] then return false,"frozen" end
    if not self._allowed_spawn_types or not self._allowed_spawn_types[spawn_type] and not self._heat_pacing:active() then return false,"not_allowed" end
    if self._heat_pacing:active() and not self._heat_pacing:current_stage_settings().allowed_spawn_types[spawn_type] then return false,"disabled_by_heat_stage" end
    return true
end)
mod:hook(MinionSpawnManager,"mutator_breed_init",function(func,self,context)
    if not mod.is_active() or not context or not context.breed_replacement then return func(self,context) end
    local combined=P.copy(context)
    combined.breed_replacement=P.copy(self._mutator_breed_data and self._mutator_breed_data.breed_replacement or {})
    for name,replacement in pairs(context.breed_replacement) do combined.breed_replacement[name]=replacement end
    return func(self,combined)
end)
mod:hook(MinionSpawnManager,"replacement_breed",function(func,self,name)
    if not mod.is_active() then return func(self,name) end
    local current,seen=name,{}
    for _=1,16 do
        if seen[current] then break end
        seen[current]=true
        local replacement=func(self,current)
        if not replacement or replacement==current then break end
        current=replacement
    end
    return current~=name and current or nil
end)
mod:hook(HordeManager,"horde",function(func,self,kind,template,side,target,composition,...)
    if not mod.is_active() or side~=2 or mod._spawning_generator then return func(self,kind,template,side,target,composition,...) end
    local banned=mod.get_session_config().banned
    local filtered=P.copy(composition)
    filtered.breeds={}
    for _,entry in ipairs(composition.breeds or {}) do
        if allowed_breed(entry.name) and not banned[entry.name] and not banned[resolve(entry.name)] then filtered.breeds[#filtered.breeds+1]=P.copy(entry) end
    end
    if #filtered.breeds==0 then return false end
    return func(self,kind,template,side,target,filtered,...)
end)
mod:hook(RoamerPacing,"_limit_roamer_breeds",function(func,self,name,...)
    local replacement,skip=func(self,name,...)
    if mod.is_active() then
        local banned=mod.get_session_config().banned
        if not allowed_breed(type(replacement)=="string" and replacement or name) or banned[name] or banned[resolve(name)] or type(replacement)=="string" and banned[resolve(replacement)] then return nil,true end
    end
    return replacement,skip
end)
-- Add tracked map slots before the native owner records their total. Each copy
-- keeps native activation, despawn and group bookkeeping, and still passes the
-- director's pool, ban and capacity checks on activation. Static slots have no
-- respawn timer, so only the quantity component applies.
mod:hook(RoamerPacing,"_generate_roamers",function(func,self,zones,roamers,...)
    local result=func(self,zones,roamers,...)
    if not mod.is_active() then return result end
    local scaling=mod.get_session_scaling()
    local remainders={}
    for i=1,#roamers do
        local source=roamers[i]
        local category=M.category_for_breed(Breeds[resolve(source.breed_name)])
        if category and (source.side_id or 2)==2 then
            local extra
            extra,remainders[category]=M.extra_count(scaling[category].quantity,remainders[category])
            local patrol=self._patrol_data and self._patrol_data.patrols[source.patrol_id]
            local patrol_member=false
            for _,index in ipairs(patrol or {}) do if index==i then patrol_member=true; break end end
            for _=1,extra do
                local clone=P.copy(source)
                clone.roamer_id=#roamers+1
                roamers[clone.roamer_id]=clone
                -- Native slots may have patrol_id without being in its roster.
                -- Only copy actual members into that roster.
                if patrol_member then patrol[#patrol+1]=clone.roamer_id else clone.patrol_id=nil end
            end
        end
    end
    return result
end)
mod:hook(RoamerPacing,"_try_activate_roamer",function(func,self,roamer,...)
    if mod.is_active() then
        local cfg=mod.get_session_config()
        local category=M.category_for_breed(Breeds[resolve(roamer.breed_name)])
        if cfg.banned[roamer.breed_name] or cfg.banned[resolve(roamer.breed_name)] then return false end
        if runtime and category then
            local id="ambient_"..category
            local generator=runtime.ambient[id]
            if not generator or not generator.enabled then return false end
            local total,by_category,by_generator=counts()
            local q=runtime.queue
            total=total+q.total
            local category_count=(by_category[category] or 0)+(q.categories[category] or 0)
            local generator_count=(by_generator[id] or 0)+(q.generators[id] or 0)
-- PERF_DEBUG_BEGIN
            S.budget(runtime.stats,generator,cfg,total,category_count,generator_count,1)
-- PERF_DEBUG_END
            if P.budget(generator,cfg,total,category_count,generator_count,1)<1 then return false end
            local pool=generator._pool_sampler
            local patrol=self._patrol_data and self._patrol_data.patrols[roamer.patrol_id]
            local patrol_member=false
            for _,index in ipairs(patrol or {}) do
                if self._roamers and self._roamers[index]==roamer then patrol_member=true; break end
            end
            if patrol_member then
                if not generator._patrol_sampler then
                    local patrol_pool={}
                    for name,weight in pairs(generator.pool) do
                        local breed=Breeds[resolve(name)]
                        if breed and breed.can_patrol then patrol_pool[name]=weight end
                    end
                    generator._patrol_sampler=P.prepare_pool(patrol_pool)
                end
                pool=generator._patrol_sampler
            end
            local name=P.pick_prepared(pool)
            if not name then return false end
            -- Keep authored placement and group bookkeeping; this lane owns the pool.
            roamer.breed_name=name
            mod._spawning_generator=id
            local ok,result=pcall(func,self,roamer,...)
            mod._spawning_generator=nil
            if not ok then error(result,0) end
            return result
        end
        if not allowed_breed(roamer.breed_name) then return false end
    end
    return func(self,roamer,...)
end)
-- Map events never disable condition actors. Only the independent Havoc-twin
-- switch intercepts this specific mutator; named mission twins use other paths.
mod:hook(MutatorSpawner,"_trigger_runtime_spawn",function(func,self,...)
    if mod.is_active() and self._template and self._template.name=="mutator_monster_havoc_twins"
        and not mod.get_session_config().havoc_twins_enabled then return end
    return func(self,...)
end)
