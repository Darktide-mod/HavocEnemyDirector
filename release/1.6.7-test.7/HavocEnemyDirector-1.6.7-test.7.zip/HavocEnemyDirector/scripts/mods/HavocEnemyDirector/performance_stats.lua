-- Test-build diagnostics. Publishing with --strip-debug removes this file
-- and all marked callers/widgets. No per-unit log output.
local mod=get_mod("HavocEnemyDirector")
mod:info("Performance test build 1.6.7-test.7 loaded; diagnostics can be toggled in Mod Options")
local S={}
local function timer_source()
    local shared=mod._comparison_debug
    if shared and type(shared.clock)=="function" then return shared.clock,shared.clock_name end
    return os and os.clock,"os.clock_quantized"
end
local phases={"tick","cleanup","population","queue","spawn","copies"}
function S.enabled() return not mod.get or mod:get("performance_debug")~=false end
function S.new()
    local stats={next_report=30,counters={},peaks={}}
    for _,phase in ipairs(phases) do stats[phase]={next=0,n=0,sum=0,peak=0,zero=0} end
    return stats
end
function S.count(stats,key,n)
    if not S.enabled() then return end
    stats.counters[key]=(stats.counters[key] or 0)+(n or 1)
end
function S.peak(stats,key,n)
    if S.enabled() then stats.peaks[key]=math.max(stats.peaks[key] or 0,n) end
end
function S.begin(stats,phase,t)
    if not S.enabled() then return end
    local timer=timer_source()
    local entry=stats[phase]
    if not timer or t<entry.next then return end
    entry.next=t+1
    return timer()
end
function S.finish(stats,phase,start)
    if start==nil then return end
    local timer=timer_source()
    if not timer then return end
    local elapsed=math.max(0,timer()-start)*1000
    local entry=stats[phase]
    entry.n=entry.n+1; entry.sum=entry.sum+elapsed; entry.peak=math.max(entry.peak,elapsed)
    if elapsed==0 then entry.zero=entry.zero+1 end
end
function S.report(stats,t,log,final)
    if not S.enabled() or not final and t<stats.next_report then return end
    stats.next_report=t+30
    local _,clock_name=timer_source()
    local parts={}
    for _,phase in ipairs(phases) do
        local e=stats[phase]
        if e.n>0 then
            parts[#parts+1]=e.zero==e.n and string.format("%s samples=%d below clock resolution",phase,e.n)
                or string.format("%s samples=%d mean=%.3fms max=%.3fms zero_delta=%d",phase,e.n,e.sum/e.n,e.peak,e.zero)
        end
        e.n=0; e.sum=0; e.peak=0; e.zero=0
    end
    local keys={}
    for key in pairs(stats.counters) do keys[#keys+1]=key end
    table.sort(keys)
    for _,key in ipairs(keys) do parts[#parts+1]=key.."="..stats.counters[key] end
    keys={};for key in pairs(stats.peaks) do keys[#keys+1]=key end; table.sort(keys)
    for _,key in ipairs(keys) do parts[#parts+1]=key.."_peak="..stats.peaks[key] end
    stats.counters={};stats.peaks={}
    if #parts>0 then log("Director performance (%s, elapsed=%.1fs, clock=%s): %s",final and "mission_end" or "periodic",t,clock_name,table.concat(parts,"; ")) end
end
return S
