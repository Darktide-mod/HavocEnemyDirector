# Havoc Enemy Director - Advanced Spawning

Havoc Enemy Director requires SoloPlay and Havoc Condition Manager, and also supports Realms sessions. It adds an Advanced page to the condition manager, groups the selected conditions' native spawn sources and builds an editable set of generators for the next mission. In Realms, spawning follows the host's configuration.

## Buff event capacity

Open Advanced director and use Buff event capacity in the top row, immediately to the right of Total cap. Click the value to enter a number or use the minus/plus buttons. This control remains available in Native mode; there is no separate Buff widget in Mod Options. This is a per-unit event limit for the local host, separate from enemy population limits. It defaults to 300 and accepts integers from 300 to 3000.

The value is controlled only by this setting. Changing enemy multipliers, resetting generators or loading templates does not change it. The setting is saved separately from generator templates, and an existing saved capacity is retained when updating.

Every unit uses the mission's fixed limit; edits apply next mission. Requests beyond that limit are rejected immediately, with no automatic capacity growth during play. This setting works in native and advanced spawn modes.

Use HCM 2.4.18-test.4 with HED 1.6.7-test.7 and fully restart after updating. HCM alone retains the native 300 limit.

## Player templates

Open Advanced → Templates. Enter a name and choose Save current setup. Names may contain up to 64 characters, including Chinese; Windows filename restrictions apply. You can type or paste into the native field. Enter or clicking elsewhere finishes editing; Esc cancels the edit. Saving uses a separate button, with confirmation before overwriting a file.

Template folder: %APPDATA%/Fatshark/Darktide/HavocEnemyDirector/templates

The folder is created when you first open the library. Copy template folder path lets you paste its location into File Explorer. It stays outside the installation folder so mod updates and Vortex redeployment do not replace your saved templates.

- Save: writes the current setup as a JSON file under the chosen name.
- Load: select a template, review its summary and confirm. This replaces the saved Director setup and its conditions, faction, environment and multipliers. It applies next mission; a running mission keeps its existing snapshot.
- Share: send the JSON file directly, or select it and use Copy share data.
- Import: place received JSON files in the folder and refresh, or use Import from clipboard, review or change the name and save. Importing a file does not apply it until you load it.
- Delete: select a template and choose Delete selected. A modal displays its full name and filename. Only Confirm delete removes that file permanently. Cancel or Esc keeps it. Deletion does not change the currently loaded setup; invalid files can also be removed this way.

Templates include custom and default-generator edits, removed generators, unit pools and weights, unit bans, population caps and spawn switches. Conditions and multipliers load together to preserve your manual generator values. Mission and difficulty remain your choice, so use the same mission and difficulty when comparing exact native defaults; some generator IDs depend on difficulty. Unavailable conditions or incompatible environments prevent loading and show a reason.

Templates use a versioned JSON data format; Lua scripts are not accepted. Limits are 256 KiB per file and 256 JSON files per folder. File reads happen only during library actions. The template library is available in advanced mode; native mode keeps advanced controls inactive. Realms spawning continues to follow the host's loaded configuration.

## Generators, pools and pacing

Edit timed and travel-based spawning, ambient enemies and supported event sources. Weak monsters retain separate handling. The director uses several groups where their behavior differs; it does not reduce every condition to one universal spawner.

- Adjust batch sizes, intervals, travel distances and generator limits.
- Change unit weights, ban units and edit enemy-category or total population caps.
- Add custom timed or travel generators; pause, delete or reset a generator.
- Restore the full default generator set from the selected conditions.

Changing conditions rebuilds the default generator configuration to match their combined effects. Set conditions and multipliers first, then make custom edits. In-mission changes are saved for the next mission snapshot.

## Editing unit pools

Use Add unit at the bottom of the pool to select an eligible unit; the menu opens upwards when needed. A new member starts at weight 1. The + beside a unit name adds it, and × removes it from this generator. The All tab also lists available units with zero weight; In pool shows the configured members. The separate Allow/Ban button controls all advanced generators and retains saved weights. Globally banned units must be unbanned before adding them through the menu.

Custom generator IDs use the lowest available number: deleting #2 from #1/#2/#3 lets the next new generator use #2. Remaining generators keep their IDs and settings.

## Multipliers and capacity

The highest selected enemy multiplier sets the default total capacity: 1× = 240, 2× = 330, 3× = 420, 4× = 510 and 5× = 600. Category defaults scale with their corresponding multipliers: at 1×, common enemies use 120, elites 45, specialists 16 and bosses 4. These are editable limits, not promised enemy counts.

Click a number to type or paste a value. Enter or clicking elsewhere confirms; Esc cancels. Hold + or − for about 400 ms to begin repeating, then repeat steps occur every 80 ms.

Batch count, interval and travel distance can be edited independently. Changing the batch count no longer recalculates the other two fields. Multiplier previews continue to follow the chosen multiplier and mode.

## Extra spawns switch

Extra spawns is on by default. Turning it off suppresses native anti-rush, split-team/loner penalties, heat-based specialist injections and ordinary elite patrols. This includes the extra native injection after a lone player is pounced.

Selected-condition generators and native patrols explicitly required by a condition remain subject to their own rules. Mission and event spawns retain their separate controls. The switch applies next mission, survives condition changes and restoring defaults, and does not add a scan of every enemy on the map.

Scripted events controls only map-event waves, continuous reinforcements and event specialists. Rotten Armour, rituals and other condition effects remain active under their own rules. Named mission actors and objective logic are retained. This switch applies next mission and survives condition edits and generator resets.

Twin ambush is a separate switch, on by default. It controls only the twin ambush supplied by Havoc difficulty conditions. Turning it on uses the native probability and trigger; turning it off suppresses that ambush. It does not affect the dedicated Twins mission or twins added to a custom pool. Settings apply next mission and survive condition edits and generator resets.

## Requirements and installation

Requires Darktide Mod Loader, Darktide Mod Framework, SoloPlay and Havoc Condition Manager. For Realms co-op, also install Realms; SoloPlay remains required. The companion versions for this release are Solo Play 2.6.2 and Havoc Condition Manager 2.4.9.

## Vortex installation

- Close the game. Set up Darktide as a managed game in Vortex and install the requirements listed above, including Havoc Condition Manager.
- Download this mod's installation ZIP from Files. In Vortex, use Install From File to import it, then enable the mod and select Deploy Mods.
- Open Load Order and enable the relevant entries in this order: SoloPlay → HavocConditionManager → HavocEnemyDirector. Preserve your other mods.
- Start the game, open Havoc Condition Manager from Mod Options and use the side arrows to reach Advanced.

## Manual installation

- Close the game and install the requirements listed above, following each dependency's instructions.
- Open the Darktide game folder. In Steam: Properties → Installed Files → Browse.
- Open the game's mods folder and extract this ZIP there. Its top-level folder is HavocEnemyDirector. The resulting path must be mods/HavocEnemyDirector.
- Open mods/mod_load_order.txt and add HavocEnemyDirector on its own line after HavocConditionManager. SoloPlay must precede both. Preserve all other entries.
- Save the file, start the game and open the Advanced page in Havoc Condition Manager.

Open Havoc Condition Manager from Mod Options, choose your conditions and multipliers, then use the side arrows to reach Advanced. English, Simplified Chinese and Traditional Chinese follow the game language; restart after changing it.

## Framework switch

Use the enable/disable switch in Darktide Mod Framework. In the hub, it applies immediately. During a local or Realms mission, the switch is saved for the next mission; the current mission keeps its initialized condition and spawning configuration. A notification confirms a deferred change. Saved settings are retained.

Havoc Condition Manager 2.4.7 or newer must be installed and enabled. When the director is disabled, its Advanced page is hidden; the manager can still run in basic mode.

## Known issues and scope

A deleted travel generator can return after a difficulty change because some generator identifiers depend on difficulty. This remains unresolved in 1.5.8. Recheck the compiled generator list after changing difficulty; the mod should not be relied upon to enforce a Boss-only run.

Director-created specialists use the game's stuck and distance cleanup checks, staggered at up to two checks per frame. Native injections, mission actors, bosses and ritual actors keep their existing owners. General enemy redeployment is not included. Higher caps can increase CPU load and frame time, especially at 5×; reduce caps or spawn rates if needed. This release supports SoloPlay and player-hosted Realms missions, with spawning controlled by the host. It does not claim official matchmaking support.

Code, condition-rule and simulated UI checks passed. There has been no new live-game test for this release. Other spawn overhauls can replace the same systems.

## Credits

Built for Havoc Condition Manager and deluxghost's Solo Play. Native systems and referenced assets: Fatshark. Game-source reference: Aussiemon/Darktide-Source-Code. This is an independent community project.

## Spawning workload

Advanced generators retain their source-specific pause, freeze, heat and challenge-pressure checks. The pressure threshold is read from the running game, including its active modifiers; population settings remain your chosen ceilings. Large batches are spread across frames with at most 24 requested units and two native calls per frame (16 common, 4 elite, 2 special or 1 boss per call). A 2 ms soft budget can stop further calls; it cannot interrupt an ongoing native call. Pending units reserve capacity, generators take turns, and failed or cancelled work releases its unused reservation. Splitting batches changes the moment-to-moment arrival pattern and can increase the number of native position queries.


