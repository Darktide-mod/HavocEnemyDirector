-- One pending batch per generator. Reservations cover every uncreated unit.
-- Native position queries remain synchronous, so each native call is small.
local Q={frame_units=24,frame_calls=2,frame_seconds=0.002,chunks={common=16,elite=4,special=2,boss=1}}
-- This clock enforces gameplay scheduling, independently of diagnostic builds.
-- Windows os.clock can be too coarse for the two-millisecond soft budget.
local function choose_clock()
    local ffi=Mods and Mods.lua and Mods.lua.ffi
    if ffi then
        local ok,timer=pcall(function()
            if not pcall(ffi.typeof,"HED_QUEUE_CLOCK_TICK") then
                ffi.cdef[[typedef long long HED_QUEUE_CLOCK_TICK;
                    int __stdcall QueryPerformanceCounter(HED_QUEUE_CLOCK_TICK*);
                    int __stdcall QueryPerformanceFrequency(HED_QUEUE_CLOCK_TICK*);]]
            end
            local win=ffi.load("kernel32")
            local value,freq=ffi.new("HED_QUEUE_CLOCK_TICK[1]"),ffi.new("HED_QUEUE_CLOCK_TICK[1]")
            assert(win.QueryPerformanceFrequency(freq)~=0 and tonumber(freq[0])>0)
            local hz=tonumber(freq[0]);assert(win.QueryPerformanceCounter(value)~=0)
            local origin=tonumber(value[0])
            return function() win.QueryPerformanceCounter(value);return (tonumber(value[0])-origin)/hz end
        end)
        if ok then return timer,"QPC" end
    end
    return nil,"os.clock_or_hard_limits"
end
Q.clock,Q.clock_name=choose_clock()
function Q.new() return {jobs={},owners={},total=0,categories={},generators={},cursor=1} end
local function reserve(q,job,delta)
    local g=job.generator
    q.total=q.total+delta
    q.categories[g.category]=(q.categories[g.category] or 0)+delta
    q.generators[g.id]=(q.generators[g.id] or 0)+delta
end
function Q.add(q,job)
    local id=job.generator.id
    if q.owners[id] or job.remaining<1 then return false end
    job.emitted=0; q.jobs[#q.jobs+1]=job; q.owners[id]=job
    reserve(q,job,job.remaining)
    return true
end
function Q.drain(q,allow,emit,finish)
    local visited,calls,requested,created=0,0,0,0
    local initial=#q.jobs
    local timer=Q.clock or os and os.clock
    local started=timer and timer()
    while #q.jobs>0 and visited<initial and calls<Q.frame_calls and requested<Q.frame_units do
        -- Soft stop between native calls; one synchronous call cannot be
        -- interrupted. Hard call/unit limits remain valid at coarse resolution.
        if calls>0 and timer and timer()-started>=Q.frame_seconds then break end
        local i=q.cursor>#q.jobs and 1 or q.cursor
        local job=q.jobs[i]
        visited=visited+1
        local chunk=math.min(job.remaining,Q.chunks[job.generator.category],Q.frame_units-requested)
        chunk=math.max(0,math.min(chunk,allow(job,chunk)))
        local actual=0
        if chunk>0 then
            calls=calls+1; requested=requested+chunk
            actual=math.max(0,math.min(chunk,emit(job.generator,chunk,job) or 0))
            reserve(q,job,-actual); job.remaining=job.remaining-actual
            job.emitted=job.emitted+actual; created=created+actual
        end
        -- A blocked/failed/partial native request is cancelled, never retried
        -- as a growing backlog. Only confirmed creations consume event tokens.
        if chunk==0 or actual<chunk or job.remaining==0 then
            reserve(q,job,-job.remaining)
            q.owners[job.generator.id]=nil
            table.remove(q.jobs,i); q.cursor=i
            finish(job)
        else q.cursor=i%#q.jobs+1 end
    end
    return calls,created,requested
end
return Q
