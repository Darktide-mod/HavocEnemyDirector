local mod=get_mod("HavocEnemyDirector")
local base=get_mod("HavocConditionManager")
local native_capacity=require("scripts/settings/buff/buff_settings").max_proc_events
local session_capacity

mod.get_buff_proc_capacity=function()
    return math.floor(mod.planner.number(mod:get("buff_proc_capacity"),native_capacity,native_capacity,3000))
end
mod.set_buff_proc_capacity=function(value)
    mod:set("buff_proc_capacity",math.floor(mod.planner.number(value,native_capacity,native_capacity,3000)))
end
mod.get_session_buff_proc_capacity=function()
    if not session_capacity then session_capacity=mod.get_buff_proc_capacity() end
    return session_capacity
end
mod.reset_buff_proc_capacity=function() session_capacity=nil end

mod:hook_require("scripts/extension_systems/buff/buff_extension_base",function(BuffExtensionBase)
    mod._capacity_buff_classes=mod._capacity_buff_classes or setmetatable({},{__mode="k"})
    if mod._capacity_buff_classes[BuffExtensionBase] then return end
    mod._capacity_buff_classes[BuffExtensionBase]=true
    mod:hook(BuffExtensionBase,"init",function(func,self,context,unit,data,...)
        self._hed_proc_pool=nil
        -- HED owns this setting independently of native/advanced spawn mode.
        -- Establish the fixed ring before native init can enqueue initial Buffs.
        if context.is_server and mod.is_gameplay_enabled() and base.has_local_gameplay_authority() then
            local capacity=mod.get_session_buff_proc_capacity()
            if capacity~=native_capacity then
                self._hed_proc_pool={capacity=capacity}
            end
        end
        return func(self,context,unit,data,...)
    end)
    mod:hook(BuffExtensionBase,"request_proc_event_param_table",function(func,self)
        local pool=self._hed_proc_pool
        if not pool then return func(self) end
        local requested=self._num_params_table_in_use+1
        if requested>pool.capacity then
            return nil
        end
        local index=(self._param_tables_start_index_reference+requested-2)%pool.capacity+1
        local params=self._proc_event_param_tables[index]
        if not params then params=Script.new_map(32); self._proc_event_param_tables[index]=params end
        self._num_params_table_in_use=requested
        return params
    end)
    mod:hook(BuffExtensionBase,"_clear_param_tables",function(func,self,count)
        local pool=self._hed_proc_pool
        if not pool then return func(self,count) end
        local index=self._param_tables_start_index_reference
        for i=1,count do
            local params=self._proc_event_param_tables[index]
            table.clear(params)
            index=index+1
            if index>pool.capacity then index=1 end
        end
        self._param_tables_start_index_reference=index
    end)
end)
