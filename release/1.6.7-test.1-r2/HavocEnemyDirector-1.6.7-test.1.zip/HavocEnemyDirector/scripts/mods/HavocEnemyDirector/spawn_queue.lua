-- One pending batch per generator. Reservations cover every uncreated unit.
-- Native position queries remain synchronous, so each native call is small.
local Q={frame_units=24,frame_calls=2,frame_seconds=0.002,chunks={common=16,elite=4,special=2,boss=1}}
function Q.new() return {jobs={},owners={},total=0,categories={},generators={},cursor=1} end
local function reserve(q,job,delta)
    local g=job.generator
    q.total=q.total+delta
    q.categories[g.category]=(q.categories[g.category] or 0)+delta
    q.generators[g.id]=(q.generators[g.id] or 0)+delta
end
function Q.add(q,job)
    local id=job.generator.id
    if q.owners[id] or job.remaining<1 then return false end
    job.emitted=0; q.jobs[#q.jobs+1]=job; q.owners[id]=job
    reserve(q,job,job.remaining)
    return true
end
function Q.drain(q,allow,emit,finish)
    local visited,calls,requested,created=0,0,0,0
    local initial=#q.jobs
    local timer=os and os.clock
    local started=timer and timer()
    while #q.jobs>0 and visited<initial and calls<Q.frame_calls and requested<Q.frame_units do
        -- Soft stop between native calls; one synchronous call cannot be
        -- interrupted. Hard call/unit limits remain valid at coarse resolution.
        if calls>0 and timer and timer()-started>=Q.frame_seconds then break end
        local i=q.cursor>#q.jobs and 1 or q.cursor
        local job=q.jobs[i]
        visited=visited+1
        local chunk=math.min(job.remaining,Q.chunks[job.generator.category],Q.frame_units-requested)
        chunk=math.max(0,math.min(chunk,allow(job,chunk)))
        local actual=0
        if chunk>0 then
            calls=calls+1; requested=requested+chunk
            actual=math.max(0,math.min(chunk,emit(job.generator,chunk,job) or 0))
            reserve(q,job,-actual); job.remaining=job.remaining-actual
            job.emitted=job.emitted+actual; created=created+actual
        end
        -- A blocked/failed/partial native request is cancelled, never retried
        -- as a growing backlog. Only confirmed creations consume event tokens.
        if chunk==0 or actual<chunk or job.remaining==0 then
            reserve(q,job,-job.remaining)
            q.owners[job.generator.id]=nil
            table.remove(q.jobs,i); q.cursor=i
            finish(job)
        else q.cursor=i%#q.jobs+1 end
    end
    return calls,created,requested
end
return Q
