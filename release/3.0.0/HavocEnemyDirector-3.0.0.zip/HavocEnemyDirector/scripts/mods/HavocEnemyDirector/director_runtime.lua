local mod=get_mod("HavocEnemyDirector")
local base=get_mod("HavocConditionManager")
local Pacing=require("scripts/managers/pacing/pacing_manager")
local Status=require("scripts/utilities/attack/player_unit_status")
local Engine=mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/director_engine")
local Spawning=mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/director_spawning")
local owner,engine,elapsed
function mod.finish_director()
    if engine then engine.finish() end
    owner=nil;engine=nil;elapsed=0
end
mod:hook_safe(Pacing,"update",function(self,dt)
    if not base.has_local_gameplay_authority() or not mod.is_gameplay_enabled() then return end
    if owner~=self then
        mod.finish_director();owner=self
        -- One immutable configuration snapshot per mission, like HCM.
        local cfg=mod.get_saved_config()
        if not cfg.director.enabled then return end
        if not base.spawn_placement then mod:notify(mod:localize("director_navigation_required"));return end
        local coarse=base.template_runtime.config().coarse
        engine=Engine.new(cfg,self._level_seed,coarse,base.template_conditions,Spawning.new(self,coarse))
    end
    if not engine then return end
    elapsed=elapsed+dt
    if elapsed<0.1 then return end
    local step=elapsed;elapsed=0
    local context=base.template_conditions.capture(Managers,Status,ScriptUnit,self._target_side_id)
    context.safe=self._disabled or self:get_in_safe_zone()
    engine.tick(step,context)
end)
mod:hook_safe(Pacing,"delete",function(self) if owner==self then mod.finish_director() end end)
return true
