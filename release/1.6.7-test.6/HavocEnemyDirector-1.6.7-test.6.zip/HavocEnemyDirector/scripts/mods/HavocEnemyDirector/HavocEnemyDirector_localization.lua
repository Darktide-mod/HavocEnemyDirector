local mod=get_mod("HavocEnemyDirector")
local localization={
-- PERF_DEBUG_BEGIN
    performance_debug={en="Performance diagnostics (test)",["zh-cn"]="性能诊断（测试）",["zh-tw"]="效能診斷（測試）"},
    performance_debug_description={en="Default on in this comparison build. Shared 30-second summaries record update intervals, population, native spawning/navigation, per-mod sampled work and Buff pressure. Disable in every diagnostic component for an observer-overhead control run.",["zh-cn"]="此对比版默认开启。共享 30 秒汇总记录更新间隔、敌人数、原版生成与选点、各模组采样耗时及 Buff 压力。测量诊断自身开销时，需关闭全部诊断组件的此选项。",["zh-tw"]="此對比版預設開啟。共用 30 秒彙整記錄更新間隔、敵人數、原版生成與選點、各模組取樣耗時及 Buff 壓力。測量診斷自身開銷時，需關閉全部診斷元件的此選項。"},
    performance_buff_warning_summary={en="Summarize repeated Buff warnings (comparison)",["zh-cn"]="重复 Buff 警告仅汇总（对照）",["zh-tw"]="重複 Buff 警告僅彙整（對照）"},
    performance_buff_warning_summary_description={en="Default off: preserve native warning output. When on, keep one native capacity warning per second and count every rejection in the 30-second summary. Does not change Buff limits or rejected events. Use the same value across comparison runs.",["zh-cn"]="默认关闭，保留原版警告输出。开启后每秒最多输出一条原版容量警告，全部拒绝次数仍计入 30 秒汇总。不改变 Buff 上限或超限拒绝行为。对比时两组使用相同设置。",["zh-tw"]="預設關閉，保留原版警告輸出。開啟後每秒最多輸出一條原版容量警告，全部拒絕次數仍計入 30 秒彙整。不變更 Buff 上限或超限拒絕行為。對比時兩組使用相同設定。"},
-- PERF_DEBUG_END
    buff_proc_capacity={en="Buff event capacity",["zh-cn"]="Buff 事件容量",["zh-tw"]="Buff 事件容量"},
    buff_proc_capacity_description={en="Fixed per-unit event limit for the local host. Defaults to 300; enter an integer from 300 to 3000. Enemy multipliers, generator resets and template loading do not change this setting. Applies next mission in both spawn modes. Excess requests are rejected; the limit never grows during gameplay.",["zh-cn"]="本地主机端每个单位的固定事件上限。默认 300，可手动输入 300–3000 的整数。敌人倍率、生成器重置和模板加载均不会改变此设置。下一局生效，适用于两种生成模式。请求超限即拒绝，游戏过程中不会自动扩容。",["zh-tw"]="本地主機端每個單位的固定事件上限。預設 300，可手動輸入 300–3000 的整數。敵人倍率、生成器重設及範本載入均不會變更此設定。下一局生效，適用於兩種生成模式。請求超限即拒絕，遊戲過程中不會自動擴容。"},
    native_saved_value={en="Saved value",["zh-cn"]="已保存数值",["zh-tw"]="已儲存數值"},
    native_saved_settings={en="Saved advanced settings · Inactive",["zh-cn"]="已保存的高级配置 · 当前不生效",["zh-tw"]="已儲存的高階設定 · 目前不生效"},
    native_inactive={en="Inactive",["zh-cn"]="未启用",["zh-tw"]="未啟用"},
    native_mode_help={en="Native mode uses the game's generators, pools and caps, including selected conditions. Adjust spawn multipliers on the Spawn scaling page.",["zh-cn"]="原版模式使用游戏生成器、池子和上限，保留所选词条的原版效果。刷怪倍率请在倍率页面调整。",["zh-tw"]="原版模式使用遊戲生成器、池子和上限，保留所選詞條的原版效果。刷怪倍率請在倍率頁面調整。"},
    native_mode_timing={en="Mode changes apply next mission. The current mission keeps its starting mode.",["zh-cn"]="模式修改在下一局生效；当前任务保持开始时的模式。",["zh-tw"]="模式修改在下一局生效；目前任務保持開始時的模式。"},
    mod_name={en="Havoc Enemy Director",["zh-cn"]="浩劫高级敌人生成器", ["zh-tw"]="浩劫高階敵人生成器"},
    mod_description={en="Edit grouped generators, pools and caps. Buff event capacity is in the top row of Advanced director. Requires an enabled Havoc Condition Manager. Framework toggles apply immediately in the hub, or next mission during a run.",["zh-cn"]="编辑分类生成器、池子与上限。Buff 事件容量位于高级生成器页顶部。需要启用浩劫词条管理器。框架开关在大厅立即生效，任务中切换则在下一局生效。", ["zh-tw"]="編輯分類生成器、池子與上限。Buff 事件容量位於高階生成器頁頂部。需要啟用浩劫詞條管理器。框架開關在大廳立即生效，任務中切換則在下一局生效。"},
    toggle_next_mission={en="Switch saved. The current mission keeps its configuration; the new state applies next mission.",["zh-cn"]="开关已保存；当前任务保持原配置，下一局应用新的开关状态。",["zh-tw"]="開關已儲存；目前任務保持原配置，下一局套用新的開關狀態。"},
    director_open={en="Advanced generator settings",["zh-cn"]="高级生成器设置", ["zh-tw"]="高階生成器設定"},
    pool_add_label={en="Add unit…",["zh-cn"]="添加单位…",["zh-tw"]="新增單位…"},
    pool_add_empty={en="No units available to add",["zh-cn"]="没有可添加的单位",["zh-tw"]="沒有可新增的單位"},
    pool_add_hint={en="Add to this generator with weight 1. Only units allowed by its category and conditions are offered; globally banned units must be unbanned first.",["zh-cn"]="以权重 1 加入当前生成器。仅可添加符合类别和词条限制的单位；全局禁用的单位需先解除禁用。",["zh-tw"]="以權重 1 加入目前生成器。僅可新增符合類別和詞條限制的單位；全域禁用的單位需先解除禁用。"},
    pool_remove_hint={en="Remove from this generator's pool. Other generators and global bans are unchanged.",["zh-cn"]="从当前生成器的池中移除，不改变其他生成器或全局禁用设置。",["zh-tw"]="從目前生成器的池中移除，不變更其他生成器或全域禁用設定。"},
    pool_locked_hint={en="Unavailable under the selected faction, category or condition replacements.",["zh-cn"]="当前阵营、类别或词条替换规则不允许此单位。",["zh-tw"]="目前陣營、類別或詞條替換規則不允許此單位。"},
    pool_ban_hint={en="Allow or ban this unit across all advanced generators. Its saved pool weights are retained.",["zh-cn"]="允许或禁止此单位在全部高级生成器中生成，保留已设置的池子权重。",["zh-tw"]="允許或禁止此單位在全部高階生成器中生成，保留已設定的池子權重。"},
}

for key,value in pairs(mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/ui_localization")) do localization[key]=value end
for key,value in pairs(mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/preset_localization")) do localization[key]=value end
return localization
