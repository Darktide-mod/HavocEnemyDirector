local mod=get_mod("HavocEnemyDirector")
return {
    name=mod:localize("mod_name"),description=mod:localize("mod_description"),is_togglable=true,
    options={widgets={
-- PERF_DEBUG_BEGIN
        {setting_id="performance_debug",type="checkbox",default_value=true,tooltip="performance_debug_description"},
        {setting_id="performance_buff_warning_summary",type="checkbox",default_value=false,tooltip="performance_buff_warning_summary_description"},
-- PERF_DEBUG_END
        {setting_id="director_open",type="button",button_text="open",function_name="open_settings"},
    }},
}
