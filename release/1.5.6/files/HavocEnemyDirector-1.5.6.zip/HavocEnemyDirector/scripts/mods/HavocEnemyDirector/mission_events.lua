local mod=get_mod("HavocEnemyDirector")

local function scenes_disabled()
    if not mod.is_active() then return false end
    local scripted=mod.get_session_config().generators.scripted_encounters
    return scripted and scripted.deleted==true or false
end

local required_tags={monster=true,captain=true,cultist_captain=true,witch=true,ritualist=true}
local function optional_wave(node)
    -- Named actors and objective-linked enemies retain their authored lifecycle.
    if node.mission_objective_id or node.side_name and node.side_name~="villains" then return false end
    for _,tags in ipairs(node.breed_tags or {}) do
        for _,tag in ipairs(tags) do if required_tags[tag] then return false end end
    end
    return true
end

mod:hook_require("scripts/managers/terror_event/terror_event_nodes",function(nodes)
    mod:hook(nodes.spawn_by_points,"update",function(func,node,...)
        if scenes_disabled() and optional_wave(node) then
            -- Complete this spawn instruction. Returning false would leave the
            -- mission waiting here and prevent later doors/flow events advancing.
            return true
        end
        return func(node,...)
    end)
    mod:hook(nodes.try_inject_special_minion,"init",function(func,node,...)
        if scenes_disabled() and optional_wave(node) then return end
        return func(node,...)
    end)
end)

mod:hook_require("scripts/managers/terror_event/terror_event_manager",function(manager)
    mod:hook(manager,"start_terror_trickle",function(func,self,...)
        if scenes_disabled() then return end
        return func(self,...)
    end)
end)
