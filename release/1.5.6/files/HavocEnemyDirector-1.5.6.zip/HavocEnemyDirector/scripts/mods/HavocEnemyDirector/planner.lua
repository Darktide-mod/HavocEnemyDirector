-- Pure planning: no game globals, settings writes or mutation of source tables.
local P = {}
P.categories = {"common","elite","special","boss"}
P.capacity_limit = 600
P.total_capacity_presets = {240,330,420,510,600}
local batches = {common=30,elite=5,special=2,boss=1}
local limits = {common=120,elite=45,special=16,boss=4}
local function copy(t,seen)
    if type(t)~="table" then return t end
    seen=seen or {}
    if seen[t] then return seen[t] end
    local result={}
    seen[t]=result
    for k,v in pairs(t) do result[k]=copy(v,seen) end
    return result
end
P.copy=copy
P.number=function(value,default,minimum,maximum)
    local n=tonumber(value)
    if not n or n~=n then n=default end
    return math.max(minimum,math.min(maximum,n))
end
P.defaults=function()
    return {enabled=true,native_extras_enabled=true,havoc_twins_enabled=true,total_cap=240,capacity_multipliers={common=1,elite=1,special=1,boss=1},category_caps=copy(limits),generators={},custom={},banned={},next_id=1,revision=1}
end
P.config=function(raw)
    local cfg=P.defaults()
    if type(raw)~="table" then return cfg end
    cfg.enabled=raw.enabled~=false
    cfg.native_extras_enabled=raw.native_extras_enabled~=false
    cfg.havoc_twins_enabled=raw.havoc_twins_enabled~=false
    cfg.capacity_preset_version=raw.capacity_preset_version==1 and 1 or nil
    cfg.total_cap=math.floor(P.number(raw.total_cap,240,1,P.capacity_limit))
    for _,category in ipairs(P.categories) do
        cfg.category_caps[category]=math.floor(P.number(raw.category_caps and raw.category_caps[category],limits[category],0,P.capacity_limit))
        cfg.capacity_multipliers[category]=math.floor(P.number(raw.capacity_multipliers and raw.capacity_multipliers[category],1,1,5))
    end
    for _,key in ipairs({"generators","custom","banned"}) do
        if type(raw[key])=="table" then cfg[key]=copy(raw[key]) end
    end
    cfg.next_id=math.floor(P.number(raw.next_id,1,1,1000000))
    cfg.revision=P.number(raw.revision,1,1,1000000000)
    cfg.conditions_signature=type(raw.conditions_signature)=="string" and raw.conditions_signature or nil
    return cfg
end
P.conditions_signature=function(conditions)
    local ids,seen={},{}
    for _,id in ipairs(conditions or {}) do
        if not seen[id] then seen[id]=true; ids[#ids+1]=id end
    end
    table.sort(ids)
    return table.concat(ids,":")
end
P.rules_key=function(rules)
    if not rules then return end
    local fields={tostring(rules.min_players or 0),rules.not_during_events and "1" or "0",
        tostring(rules.active_limit or 0),tostring(rules.cooldown or 0)}
    for _,key in ipairs({"hordes","roamers","specials","monsters","trickle_hordes"}) do
        fields[#fields+1]=tostring(rules.pause and rules.pause[key] or 0)
    end
    return "rules_"..table.concat(fields,"_")
end
P.collect=function(value,breeds,resolve,tier)
    local result,seen,leaves={}, {}, 0
    local function add(name,amount)
        name=resolve and resolve(name) or name
        if breeds[name] then result[name]=(result[name] or 0)+amount end
    end
    local function walk(t)
        if type(t)=="string" then add(t,1); return end
        if type(t)~="table" or seen[t] then return end
        seen[t]=true
        -- A native difficulty ladder contains complete compositions at each tier.
        if t[1] and type(t[1])=="table" and t[1].breeds and t[1].weight==nil then
            walk(t[math.min(tier or 5,#t)])
        elseif t.breeds and type(t.breeds)=="table" then
            local weight=tonumber(t.weight) or 1
            leaves=leaves+weight
            for _,entry in ipairs(t.breeds) do
                if type(entry)=="string" then add(entry,weight)
                elseif type(entry)=="table" and entry.name then
                    local n=entry.amount or 1
                    if type(n)=="table" then n=((tonumber(n[1]) or 0)+(tonumber(n[2]) or tonumber(n[1]) or 0))/2 end
                    add(entry.name,(tonumber(n) or 0)*weight)
                end
            end
        elseif t.name and breeds[t.name] and t.amount then
            local amount=t.amount
            add(t.name,type(amount)=="table" and ((amount[1]+amount[2])/2) or amount)
        else
            for key,child in pairs(t) do if key~="name" then walk(child) end end
        end
    end
    walk(value)
    if leaves>1 then for name,weight in pairs(result) do result[name]=weight/leaves end end
    return result
end
-- Native shared specialists retain their explicit all-factions exemption.
P.faction_allowed=function(breed,faction)
    if not breed then return false end
    if faction~="renegade" and faction~="cultist" then return true end
    -- 1.12.5 labels the Dreg vanguard as renegade in breed metadata, but
    -- cultists_roamer_packs and havoc_cultist_horde_compositions place it
    -- exclusively in the cultist roster. Use that authored roster identity.
    local sub=breed.name=="cultist_vanguard" and "cultist" or breed.sub_faction_name
    return breed.can_be_used_for_all_factions or (sub~="renegade" and sub~="cultist") or sub==faction
end
P.filter_pool=function(pool,overrides,banned,breeds,category_for,category,resolve,faction)
    local result,merged={},copy(pool)
    for name,weight in pairs(overrides or {}) do merged[name]=weight end
    for name,weight in pairs(merged) do
        local resolved=resolve and resolve(name) or name
        local breed=breeds[resolved]
        local allowed=P.faction_allowed(breed,faction) and category_for(breed)==category
        if allowed and not banned[name] and not banned[resolved] and type(weight)=="number" and weight>0 then
            result[resolved]=(result[resolved] or 0)+math.min(weight,10000)
        end
    end
    return result
end
P.compile=function(sources,raw,breeds,category_for,resolve)
    local cfg=P.config(raw)
    local groups={}
    for _,source in ipairs(sources) do
        local pool=source.pool or P.collect(source.composition,breeds,resolve,source.tier)
        local interval=P.number(source.interval,60,1,3600)
        for name,weight in pairs(pool) do
            local category=category_for(breeds[name])
            if category and weight>0 and P.faction_allowed(breeds[name],sources.faction) then
                local kind=source.kind or "timer"
                local id=kind.."_"..category..(source.profile and "_"..source.profile or "")
                local g=groups[id]
                if not g then
                    g={id=id,kind=kind,category=category,pool={},sources={},rate=0,distance_rate=0,profile=source.profile,health={},rules=copy(source.rules),default_cap=source.cap,breed_caps=copy(source.breed_caps)}
                    groups[id]=g
                end
                g.sources[source.id]=true
                if source.rules and source.rules.horde_travel then g.horde_amount=(g.horde_amount or 0)+weight end
                g.pool[name]=(g.pool[name] or 0)+weight/interval
                if source.health_modifiers and source.health_modifiers[name] then g.health[name]=source.health_modifiers[name] end
                g.rate=g.rate+weight/interval
                if source.distance and source.distance>0 then g.distance_rate=g.distance_rate+weight/source.distance end
            end
        end
    end
    local result={}
    local function finish(g)
        local override=cfg.generators[g.id] or {}
        if override.deleted then return end
        g.enabled=override.enabled~=false
        local default_count=batches[g.category]
        g.count=math.floor(P.number(override.count,default_count,1,100))
        -- Derive cadence from the original batch, before applying independent edits.
        -- A larger batch must increase output, not also lengthen both spawn gates.
        g.interval=P.number(override.interval,default_count/math.max(g.rate,0.001),1,3600)
        g.distance=P.number(override.distance,g.kind=="travel" and default_count/math.max(g.distance_rate,0.001) or 0,0,2000)
        g.cap=math.floor(P.number(override.cap,(g.default_cap or limits[g.category])*cfg.capacity_multipliers[g.category],0,P.capacity_limit))
        g.faction=sources.faction
        g.pool=P.filter_pool(g.pool,override.pool,cfg.banned,breeds,category_for,g.category,resolve,sources.faction)
        -- Rescale for editing without rounding the probabilities used to spawn.
        if not override.pool then
            local highest=0
            for _,weight in pairs(g.pool) do highest=math.max(highest,weight) end
            if highest>0 then for name,weight in pairs(g.pool) do g.pool[name]=weight/highest*10 end end
        end
        result[#result+1]=g
    end
    for _,kind in ipairs({"timer","travel","event","ambient"}) do
        for _,category in ipairs(P.categories) do
            local id=kind.."_"..category
            if groups[id] then finish(groups[id]) end
            local variants={}
            for name,entry in pairs(groups) do
                if entry.kind==kind and entry.category==category and name~=id then variants[#variants+1]=name end
            end
            table.sort(variants)
            for _,name in ipairs(variants) do finish(groups[name]) end
        end
    end
    for _,custom in ipairs(cfg.custom) do
        if type(custom)=="table" and batches[custom.category] and type(custom.id)=="string" then
            local inherited=groups["timer_"..custom.category] or groups["travel_"..custom.category]
            finish({id=custom.id,kind=custom.kind=="travel" and "travel" or "timer",category=custom.category,
                pool=copy(custom.pool or inherited and inherited.pool or {}),sources={custom=true},rate=batches[custom.category]/60,distance_rate=0})
        end
    end
    return result
end
P.pick=function(pool,random)
    local names,total={},0
    for name,weight in pairs(pool) do if weight>0 then names[#names+1]=name end end
    table.sort(names)
    for _,name in ipairs(names) do total=total+pool[name] end
    if total<=0 then return end
    local roll=(random or math.random)()*total
    for _,name in ipairs(names) do
        roll=roll-pool[name]
        if roll<=0 then return name end
    end
    return names[#names]
end
-- Effective values are separate from editable base values, so saving an edit
-- cannot apply the multiplier a second time.
P.default_capacity=function(category) return limits[category] end
P.effective=function(generator,scaling)
    local g=copy(generator)
    local factors=scaling and scaling[g.category] or {}
    g.speed=factors.speed or 1
    g.quantity=factors.quantity or 1
    g.multiplier=factors.multiplier or 1
    g.mode=factors.mode or "quantity"
    g.count=g.count*g.quantity
    if g.kind~="ambient" then
        g.interval=g.interval/g.speed
        g.distance=g.distance/g.speed
    end
    return g
end
P.batch=function(generator,remainder)
    local total=generator.count+(remainder or 0)
    local count=math.floor(total+0.000001)
    return count,math.max(0,total-count)
end
P.budget=function(generator,cfg,total,category_alive,generator_alive,requested)
    return math.max(0,math.floor(math.min(requested or generator.count,cfg.total_cap-total,
        (cfg.category_caps[generator.category] or 0)-category_alive,generator.cap-generator_alive)))
end
return P
