local mod=get_mod("HavocEnemyDirector")
local P=mod.planner
local labels={common=mod:localize("ui_001"),elite=mod:localize("ui_002"),special=mod:localize("ui_003"),boss="Boss"}
local kinds={timer=mod:localize("ui_004"),travel=mod:localize("ui_005"),event=mod:localize("ui_006"),ambient=mod:localize("ui_007")}
local modes={quantity=mod:localize("ui_008"),speed=mod:localize("ui_009"),mixed=mod:localize("ui_010")}
local function mutate(fn) local cfg=mod.get_config(); fn(cfg); mod.save_config(cfg) end
local function generator_name(g)
    return (kinds[g.kind] or g.kind).." · "..labels[g.category]..(g.profile=="weak" and mod:localize("ui_011") or g.rules and g.rules.min_players and mod:localize("ui_012") or "")..
        (g.id:find("custom_",1,true) and " #"..g.id:match("%d+$") or "")
end
local function display_name(name,breed)
    local key=breed.display_name
    local ok,text=pcall(Localize,key or "")
    if ok and text and text~="" and text~=key and not text:find("unlocalized",1,true) then return text end
    return name:gsub("_"," ")
end
mod.unit_display_name=display_name
mod.build_dashboard=function(view,ui)
    local cfg=mod.get_config()
    local scaling=mod.get_spawn_scaling()
    local preview=P.copy(cfg)
    preview.banned={} -- Keep configured weights visible even while a unit is banned.
    local sources=mod.collect_sources(true)
    local generators=P.compile(sources,preview,mod.breeds,mod.category_for,mod.preview_resolve)
    local g,selected_index
    for i,entry in ipairs(generators) do if entry.id==view._hed_generator_id then g=entry; selected_index=i end end
    if not g then g=generators[1]; view._hcm_offsets.generators=0 end
    view._hed_generator_id=g and g.id or nil
    selected_index=selected_index or 1
    ui:panel("director_global",105,220,1710,112)
    ui:choice("director_enabled",120,232,202,42,cfg.enabled and "advanced" or "native",
        {{"advanced",mod:localize("ui_013")},{"native",mod:localize("ui_014")}},function(value) mutate(function(c) c.enabled=value=="advanced" end) end)
    ui:stepper("total_cap",340,232,300,mod:localize("ui_015"),cfg.total_cap,function(d) mutate(function(c) c.total_cap=P.number(c.total_cap+d,240,1,P.capacity_limit) end) end,nil,
        {label=mod:localize("ui_015"),value=cfg.total_cap,min=1,max=P.capacity_limit,integer=true,set=function(value) mutate(function(c) c.total_cap=value end) end})
    local faction_text=sources.faction=="renegade" and mod:localize("ui_016") or sources.faction=="cultist" and mod:localize("ui_017") or mod:localize("ui_010")
    ui:text("preview_summary",666,235,460,38,mod:localize("ui_018",#sources,#generators,faction_text),17,"muted")
    ui:checkbox("native_extras",1140,232,300,42,mod:localize("ui_019")..(cfg.native_extras_enabled and mod:localize("ui_020") or mod:localize("ui_021")),function()
        mutate(function(c) c.native_extras_enabled=not c.native_extras_enabled end)
    end,cfg.native_extras_enabled,mod:localize("ui_022"))
    ui:button("restore_all_generators",1450,232,348,42,mod:localize("ui_023"),function()
        mod.restore_defaults()
        view._hed_generator_id=nil; view._hcm_offsets.generators=0; view._hcm_offsets.pool=0; view._hed_pool_filter="all"
    end,false,mod:localize("ui_024"))
    for i,category in ipairs(P.categories) do
        local label_index=#ui.items+1
        ui:stepper("cap_"..category,120+(i-1)*280,282,270,labels[category],cfg.category_caps[category],function(d)
            mutate(function(c) c.category_caps[category]=P.number(c.category_caps[category]+d,0,0,P.capacity_limit) end)
        end,labels[category]..mod:localize("ui_026"),{label=labels[category]..mod:localize("ui_026"),value=cfg.category_caps[category],min=0,max=P.capacity_limit,integer=true,
            set=function(value) mutate(function(c) c.category_caps[category]=value end) end})
        ui.items[label_index].font=18
    end
    local scripted=cfg.generators.scripted_encounters or {}
    ui:checkbox("scripted",1250,282,270,44,mod:localize("ui_027")..(scripted.deleted and mod:localize("ui_021") or mod:localize("ui_028")),function()
        mutate(function(c) c.generators.scripted_encounters={deleted=not scripted.deleted} end)
    end,not scripted.deleted,mod:localize("ui_029"))
    ui:checkbox("havoc_twins",1530,282,268,44,mod:localize("twins_label")..(cfg.havoc_twins_enabled and mod:localize("ui_020") or mod:localize("ui_021")),function()
        mutate(function(c) c.havoc_twins_enabled=not c.havoc_twins_enabled end)
    end,cfg.havoc_twins_enabled,mod:localize("twins_hint"))
    ui:panel("generators_panel",105,350,345,612)
    ui:panel("parameters_panel",470,350,465,612)
    ui:panel("pool_panel",955,350,860,612)
    ui:text("generator_heading",115,356,315,40,mod:localize("ui_030"),26)
    local offset=ui:window("generators",#generators,8,1,120,834,315)
    for i=1,math.min(8,#generators-offset) do
        local entry=generators[offset+i]
        local item=ui:button("generator_"..entry.id,120,406+(i-1)*53,315,48,
            (entry.enabled and "" or "Ⅱ ")..generator_name(entry),function()
                view._hed_generator_id=entry.id; view._hcm_offsets.pool=0
            end,g and entry.id==g.id)
        item.center=false; item.font=20; item.scroll="generators"
    end
    view._hed_add_category=view._hed_add_category or 1
    local category_options={}
    for i,category in ipairs(P.categories) do category_options[#category_options+1]={i,labels[category]} end
    ui:choice("new_category",120,879,201,40,view._hed_add_category,category_options,function(value)
        view._hed_add_category=value
    end,mod:localize("ui_031"))
    ui:button("add_generator",329,879,106,40,mod:localize("ui_032"),function()
        mutate(function(c)
            local category=P.categories[view._hed_add_category]
            local pool={}
            for _,entry in ipairs(generators) do if entry.category==category then for name,weight in pairs(entry.pool) do pool[name]=weight end end end
            local id="custom_"..c.next_id; c.next_id=c.next_id+1
            c.custom[#c.custom+1]={id=id,category=category,kind="timer",pool=pool}
            view._hed_generator_id=id; view._hcm_offsets.generators=math.max(0,#generators+1-8); view._hcm_offsets.pool=0
        end)
    end)
    ui:text("generator_list_help",120,926,315,28,mod:localize("ui_033"),16,"muted")
    if not g then
        ui:text("no_generator",490,412,420,160,mod:localize("ui_034"),23,"muted")
        return
    end
    ui:text("current_generator",485,357,435,44,generator_name(g),24,"gold")
    local function set_parameter(key,value)
        mutate(function(c)
            c.generators[g.id]=c.generators[g.id] or {}
            c.generators[g.id][key]=value
        end)
    end
    local function edit(key,d,minimum,maximum)
        set_parameter(key,P.number(g[key]+d,g[key],minimum,maximum))
    end
    local effective=P.effective(g,scaling)
    ui:text("generator_scaling",485,400,130,28,string.format("%d× %s",effective.multiplier,modes[effective.mode] or modes.quantity),18,"gold")
    ui:text("generator_base_heading",620,400,140,28,mod:localize("ui_035"),17,"muted").center=true
    ui:text("generator_effective_heading",774,400,146,28,mod:localize("ui_036"),17,"gold").center=true
    local parameters={{"count",g.kind=="ambient" and mod:localize("ui_037") or mod:localize("ui_038"),1,100},{"interval",mod:localize("ui_039"),1,3600},{"distance",mod:localize("ui_040"),0,2000},{"cap",mod:localize("ui_041"),0,P.capacity_limit}}
    for i,param in ipairs(parameters) do
        local key=param[1]
        local applicable=key=="cap" or g.kind~="ambient" and (key~="distance" or g.kind=="travel")
        local value=applicable and ((key=="interval" or key=="distance") and string.format("%.1f",g[key]) or tostring(g[key])) or "—"
        local scaled=applicable and (key=="cap" and tostring(effective.cap) or string.format("%.2f",effective[key])) or "—"
        if key=="count" and g.kind=="ambient" then scaled=string.format("×%.2f",effective.quantity) end
        local y=438+(i-1)*60
        ui:add("generator_"..key.."_label",485,y,130,44,param[2],{fill=true,font=19})
        ui:repeat_button("generator_"..key.."_minus",620,y,32,44,"−",applicable and function() edit(key,-1,param[3],param[4]) end)
        ui:number("generator_"..key.."_value",654,y,72,44,value,applicable and
            {label=param[2],value=g[key],min=param[3],max=param[4],integer=key=="count" or key=="cap",set=function(n) set_parameter(key,n) end},19)
        ui:repeat_button("generator_"..key.."_plus",728,y,32,44,"+",applicable and function() edit(key,1,param[3],param[4]) end)
        ui:add("generator_"..key.."_effective",774,y,146,44,scaled,{fill=true,font=22,center=true,color=scaled~="—" and (key~="cap" or effective.cap~=g.cap) and "gold" or "muted"})
    end
    ui:checkbox("generator_enabled",485,686,210,44,g.enabled and mod:localize("ui_042") or mod:localize("ui_043"),
        function() mutate(function(c) c.generators[g.id]=c.generators[g.id] or {}; c.generators[g.id].enabled=not g.enabled end) end,
        g.enabled)
    ui:choice("generator_trigger",707,686,213,44,g.kind,
        g.id:find("custom_",1,true) and {{"timer",mod:localize("ui_004")},{"travel",mod:localize("ui_005")}} or {{g.kind,kinds[g.kind]}},
        g.id:find("custom_",1,true) and function(value)
            mutate(function(c) for _,entry in ipairs(c.custom) do if entry.id==g.id then entry.kind=value end end end)
        end,mod:localize("ui_044"))
    local status=mod:localize("ui_045",effective.multiplier,modes[effective.mode] or modes.quantity)
    if g.kind=="ambient" then
        status=status..mod:localize("ui_046",effective.quantity)..mod:localize("ui_047")
    else
        status=status..mod:localize("ui_048")
        if g.kind=="travel" then status=status..mod:localize("ui_049")
        elseif g.kind=="event" then status=status..mod:localize("ui_050")
        else status=status..mod:localize("ui_051",effective.count*60/effective.interval) end
    end
    status=status..mod:localize("ui_052")
    ui:text("generator_explanation",485,743,435,96,status,18,"muted")
    ui:button("delete_generator",485,847,210,44,mod:localize("ui_053"),function()
        mutate(function(c)
            local custom=false
            for i=#c.custom,1,-1 do
                if c.custom[i].id==g.id then table.remove(c.custom,i); custom=true end
            end
            -- Derived defaults need an exclusion marker or source compilation would recreate them.
            c.generators[g.id]=not custom and {deleted=true} or nil
        end)
        local neighbour=generators[selected_index+1] or generators[selected_index-1]
        view._hed_generator_id=neighbour and neighbour.id or nil; view._hcm_offsets.pool=0
    end,false,mod:localize("ui_054"),true)
    ui:button("restore_generator",707,847,213,44,mod:localize("ui_055"),function() mutate(function(c) c.generators[g.id]={} end) end)
    ui:text("generator_step_hint",485,902,435,54,mod:localize("ui_056"),17,"muted")
    local breeds={}
    local filter=view._hed_pool_filter or "all"
    for name,breed in pairs(mod.breeds) do
        -- Flying mission vehicles are not members of a navigable ground-unit pool.
        if type(name)=="string" and name~="attack_valkyrie" and not breed.airbound and mod.category_for(breed)==g.category then
            if filter=="all" or filter=="included" and (g.pool[name] or 0)>0 or filter=="banned" and cfg.banned[name] then
                breeds[#breeds+1]={name=name,display=display_name(name,breed)}
            end
        end
    end
    table.sort(breeds,function(a,b) return a.display==b.display and a.name<b.name or a.display<b.display end)
    ui:text("pool_heading",970,356,370,40,mod:localize("ui_057")..labels[g.category],26)
    for i,f in ipairs({{"all",mod:localize("ui_058")},{"included",mod:localize("ui_059")},{"banned",mod:localize("ui_060")}}) do
        ui:button("pool_filter_"..f[1],1420+(i-1)*126,357,114,38,f[2],function() view._hed_pool_filter=f[1]; view._hcm_offsets.pool=0 end,filter==f[1])
    end
    for column=0,1 do
        local x=970+column*420
        ui:text("pool_name_heading_"..column,x,404,209,28,mod:localize("ui_061"),17,"muted")
        ui:text("pool_weight_heading_"..column,x+211,404,112,28,mod:localize("ui_062"),17,"muted").center=true
        ui:text("pool_allowed_heading_"..column,x+330,404,70,28,mod:localize("ui_063"),17,"muted").center=true
    end
    local pool_offset=ui:window("pool",#breeds,14,2,970,884,830)
    if #breeds==0 then ui:text("empty_pool",982,460,794,80,mod:localize("ui_064"),22,"muted") end
    for i=1,math.min(14,#breeds-pool_offset) do
        local entry=breeds[pool_offset+i]; local name=entry.name
        local x,y=970+(i-1)%2*420,449+math.floor((i-1)/2)*60
        local weight=g.pool[name] or 0
        local eligible=P.faction_allowed(mod.breeds[mod.preview_resolve(name)],sources.faction)
        local weight_text=weight==0 and "0" or weight<0.1 and "<0.1" or string.format("%.1f",weight):gsub("%.0$","")
        local first=#ui.items+1
        ui:add("unit_"..name,x,y,209,48,entry.display,{fill=true,font=19,color=(not eligible or cfg.banned[name]) and "muted" or nil})
        local function set_weight(value)
            mutate(function(c)
                c.generators[g.id]=c.generators[g.id] or {}
                c.generators[g.id].pool=c.generators[g.id].pool or P.copy(g.pool)
                c.generators[g.id].pool[name]=value
            end)
        end
        ui:repeat_button("weight_minus_"..name,x+211,y,32,48,"−",eligible and function() set_weight(P.number(weight-1,0,0,100)) end)
        ui:number("weight_"..name,x+245,y,44,48,weight_text,eligible and
            {label=mod:localize("ui_065"),value=weight,min=0,max=100,set=set_weight},18)
        ui:repeat_button("weight_plus_"..name,x+291,y,32,48,"+",eligible and function() set_weight(P.number(weight+1,0,0,100)) end)
        ui:button("ban_"..name,x+330,y,70,48,not eligible and mod:localize("ui_066") or cfg.banned[name] and mod:localize("ui_067") or mod:localize("ui_068"),eligible and function() mutate(function(c) c.banned[name]=not c.banned[name] or nil end) end,cfg.banned[name],not eligible and mod:localize("ui_069") or nil,cfg.banned[name])
        for j=first,#ui.items do ui.items[j].scroll="pool" end
    end
    ui:text("pool_help",970,925,574,28,mod:localize("ui_070"),17,"muted")
    ui:button("clear_pool",1570,921,230,36,mod:localize("ui_071"),function()
        mutate(function(c)
            c.generators[g.id]=c.generators[g.id] or {}; c.generators[g.id].pool={}
            for name,breed in pairs(mod.breeds) do if mod.category_for(breed)==g.category then c.generators[g.id].pool[name]=0 end end
        end)
    end,false,nil,true)
end
