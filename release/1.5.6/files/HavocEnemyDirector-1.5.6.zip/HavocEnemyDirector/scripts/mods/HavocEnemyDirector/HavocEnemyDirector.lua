local mod=get_mod("HavocEnemyDirector")
local base=get_mod("HavocConditionManager")
if not base then mod:error("HavocConditionManager must load before HavocEnemyDirector"); return end
local Toggle=base:io_dofile("HavocConditionManager/scripts/mods/HavocConditionManager/runtime_toggle")
if type(Toggle)~="function" then mod:error("HavocConditionManager 2.4.7 or newer is required; update the companion mod first"); return end
local solo=get_mod("SoloPlay")
local toggle=Toggle(mod,function() return solo and solo.has_local_gameplay_authority and solo.has_local_gameplay_authority() or false end,base)
mod.is_gameplay_enabled=toggle.active
mod.planner=mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/planner")
local P=mod.planner
local cfg=P.config(mod:get("director_config_v1"))
local function apply_presets(category,force)
    if not mod.collect_sources then return false end
    if cfg.capacity_preset_version~=1 then category=nil end
    local scaling=mod.get_spawn_scaling()
    local changed,highest={},1
    for _,name in ipairs(P.categories) do
        local n=scaling[name].multiplier
        highest=math.max(highest,n)
        if (not category or category==name) and (force or cfg.capacity_preset_version~=1 or cfg.capacity_multipliers[name]~=n) then changed[name]=n end
    end
    if not next(changed) then return false end
    -- Rebuild caps from native/source defaults, never multiply an already scaled cap.
    local defaults=P.copy(cfg)
    for _,name in ipairs(P.categories) do defaults.capacity_multipliers[name]=1 end
    for _,override in pairs(defaults.generators) do override.cap=nil; override.deleted=nil end
    local sources=mod.collect_sources(true)
    local generators=P.compile(sources,defaults,mod.breeds,mod.category_for,mod.preview_resolve)
    cfg.total_cap=P.total_capacity_presets[highest]
    for name,n in pairs(changed) do
        cfg.category_caps[name]=P.default_capacity(name)*n
        cfg.capacity_multipliers[name]=n
    end
    for _,g in ipairs(generators) do
        if changed[g.category] then
            cfg.generators[g.id]=cfg.generators[g.id] or {}
            cfg.generators[g.id].cap=math.min(P.capacity_limit,g.cap*changed[g.category])
        end
    end
    cfg.capacity_preset_version=1
    return true
end
local function rebuild_defaults(signature)
    local previous=cfg
    cfg=P.defaults()
    cfg.enabled=previous.enabled -- Rebuilding does not switch the chosen generation mode.
    cfg.native_extras_enabled=previous.native_extras_enabled
    cfg.havoc_twins_enabled=previous.havoc_twins_enabled
    cfg.generators.scripted_encounters=P.copy(previous.generators.scripted_encounters)
    cfg.revision=previous.revision+1
    cfg.conditions_signature=signature
    apply_presets(nil,true)
    mod:set("director_config_v1",cfg)
end
mod.restore_defaults=function()
    rebuild_defaults(P.conditions_signature(base.get_selected_conditions()))
end
mod.synchronize_conditions=function()
    if not base.get_selected_conditions then return false end
    local selected=base.get_selected_conditions()
    local signature=P.conditions_signature(selected)
    if cfg.conditions_signature==signature then return false end
    rebuild_defaults(signature)
    mod:info("Rebuilt generator defaults for %d selected conditions",#selected)
    return true
end
mod.get_config=function() mod.synchronize_conditions(); return P.copy(cfg) end
mod.peek_config=function() return cfg end
mod.save_config=function(value)
    cfg=P.config(value)
    cfg.conditions_signature=P.conditions_signature(base.get_selected_conditions())
    cfg.revision=cfg.revision+1
    mod:set("director_config_v1",cfg)
end
mod.apply_capacity_presets=function(category)
    if mod.synchronize_conditions() then return end
    if apply_presets(category) then
        cfg.revision=cfg.revision+1
        mod:set("director_config_v1",cfg)
    end
end
mod.capacity_stats=mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/capacity_stats")
mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/runtime")
mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/mission_events")
mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/editor")
mod.apply_capacity_presets()
-- Spawn inside the gameplay pacing update; DMF's outer update can run before
-- the engine has refreshed the temporary position vectors used by spawn queries.
mod.update=nil
mod.on_game_state_changed=function(status,state)
    if state~="GameplayStateRun" then return end
    if status=="exit" then mod.reset_runtime(); toggle.finish() elseif status=="enter" then toggle.start() end
end
mod.on_unload=mod.reset_runtime
mod.open_settings=function()
    if not mod:is_enabled() or not base:is_enabled() then return end
    mod._open_settings_requested=true
    base.open_condition_manager_view()
end
local function state_changed(initial_call)
    if not toggle.changed(initial_call) then mod.reset_runtime() end
    mod._open_settings_requested=nil
    if not initial_call and base.close_condition_manager_view then base.close_condition_manager_view() end
end
mod.on_enabled=state_changed
mod.on_disabled=state_changed
mod.on_base_state_changed=state_changed
