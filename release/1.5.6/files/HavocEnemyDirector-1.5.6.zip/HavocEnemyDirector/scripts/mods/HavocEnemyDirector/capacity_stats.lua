-- Counts limiting checks, not unique lost enemies: a blocked request can retry.
local S={}
S.new=function() return {elapsed=0,next_report=30,entries={}} end
local function entry(stats,key,current,cap)
    local e=stats.entries[key]
    if not e then e={peak=0,cap=cap,full_seconds=0,limited_checks=0}; stats.entries[key]=e end
    e.peak=math.max(e.peak,current); e.cap=cap
    return e
end
S.observe=function(stats,dt,total,categories,generators,cfg,compiled)
    stats.elapsed=stats.elapsed+dt
    local function sample(key,n,cap)
        local e=entry(stats,key,n,cap)
        if n>=cap then e.full_seconds=e.full_seconds+dt end
    end
    sample("total",total,cfg.total_cap)
    for category,cap in pairs(cfg.category_caps) do sample("category:"..category,categories[category] or 0,cap) end
    for _,g in ipairs(compiled) do if g.enabled then sample("generator:"..g.id,generators[g.id] or 0,g.cap) end end
end
S.check=function(stats,key,current,cap,requested)
    if cap-current<(requested or 1) then
        local e=entry(stats,key,current,cap)
        e.limited_checks=e.limited_checks+1
    end
end
S.budget=function(stats,g,cfg,total,category_alive,generator_alive,requested)
    S.check(stats,"total",total,cfg.total_cap,requested)
    S.check(stats,"category:"..g.category,category_alive,cfg.category_caps[g.category],requested)
    S.check(stats,"generator:"..g.id,generator_alive,g.cap,requested)
end
S.report=function(stats,log,final)
    if not final and stats.elapsed<stats.next_report then return end
    stats.next_report=stats.elapsed+30
    local keys={}
    for key,e in pairs(stats.entries) do
        if key=="total" or key:find("^category:") or e.limited_checks>0 or e.full_seconds>0 then keys[#keys+1]=key end
    end
    table.sort(keys)
    local parts={}
    for _,key in ipairs(keys) do
        local e=stats.entries[key]
        parts[#parts+1]=string.format("%s peak=%d/%d full=%.1fs limited_checks=%d",key,e.peak,e.cap,e.full_seconds,e.limited_checks)
    end
    if #parts>0 then log("Capacity summary (%s, %.1fs sampled): %s",final and "mission_end" or "periodic",stats.elapsed,table.concat(parts,"; ")) end
end
return S
