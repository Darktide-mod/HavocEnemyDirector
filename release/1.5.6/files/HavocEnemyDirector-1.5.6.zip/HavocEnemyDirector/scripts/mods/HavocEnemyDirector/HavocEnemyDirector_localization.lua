local mod=get_mod("HavocEnemyDirector")
local localization={
    mod_name={en="Havoc Enemy Director",["zh-cn"]="浩劫高级敌人生成器", ["zh-tw"]="浩劫高階敵人生成器"},
    mod_description={en="Edit grouped generators, pools and caps. Requires an enabled Havoc Condition Manager. Framework toggles apply immediately in the hub, or next mission during a run.",["zh-cn"]="编辑分类生成器、池子与上限，需要启用浩劫词条管理器。框架开关在大厅立即生效，任务中切换则在下一局生效。", ["zh-tw"]="編輯分類生成器、池子與上限，需要啟用浩劫詞條管理器。框架開關在大廳立即生效，任務中切換則在下一局生效。"},
    toggle_next_mission={en="Switch saved. The current mission keeps its configuration; the new state applies next mission.",["zh-cn"]="开关已保存；当前任务保持原配置，下一局应用新的开关状态。",["zh-tw"]="開關已儲存；目前任務保持原配置，下一局套用新的開關狀態。"},
    director_open={en="Advanced generator settings",["zh-cn"]="高级生成器设置", ["zh-tw"]="高階生成器設定"},
}

for key,value in pairs(mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/ui_localization")) do localization[key]=value end
return localization
