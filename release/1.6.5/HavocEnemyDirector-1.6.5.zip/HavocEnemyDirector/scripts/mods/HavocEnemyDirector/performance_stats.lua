-- os.clock is retained by the game's retail Lua sandbox. Unlike the engine's
-- frame-latched time_since_launch it can advance inside one update. Its
-- platform-dependent resolution is reported honestly; zero deltas do not
-- establish zero cost. This measures sampled calls, not whole-game FPS.
local S={}
S.new=function() return {next_report=30,tick={next=0,n=0,sum=0,peak=0,zero=0},cleanup={next=0,n=0,sum=0,peak=0,zero=0}} end
S.begin=function(stats,phase,t)
    local timer=os and os.clock
    local entry=stats[phase]
    if not timer or t<entry.next then return end
    entry.next=t+1
    return timer()
end
S.finish=function(stats,phase,start)
    if start==nil then return end
    local elapsed=math.max(0,os.clock()-start)*1000
    local entry=stats[phase]
    entry.n=entry.n+1; entry.sum=entry.sum+elapsed; entry.peak=math.max(entry.peak,elapsed)
    if elapsed==0 then entry.zero=entry.zero+1 end
end
S.report=function(stats,t,log,final)
    if not final and t<stats.next_report then return end
    stats.next_report=t+30
    local tick,cleanup=stats.tick,stats.cleanup
    if tick.n+cleanup.n==0 then return end
    local function summary(entry)
        if entry.n==0 then return "no samples" end
        if entry.zero==entry.n then return string.format("samples=%d below clock resolution",entry.n) end
        return string.format("samples=%d mean=%.3fms max=%.3fms zero_delta=%d (quantized)",entry.n,entry.sum/entry.n,entry.peak,entry.zero)
    end
    log("Director performance (%s, elapsed=%.1fs, clock=os.clock): tick %s; cleanup %s",
        final and "mission_end" or "periodic",t,summary(tick),summary(cleanup))
    for _,entry in ipairs({tick,cleanup}) do entry.n=0; entry.sum=0; entry.peak=0; entry.zero=0 end
end
return S
