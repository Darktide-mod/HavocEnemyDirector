-- The native injected-only switch stops positive timers, but expired ordinary
-- slots still enter disabler selection and failed-spawn telemetry. Park those
-- timers only for this update; leave injections, queued spawns and living units
-- to the original update. No slot/template state survives the call.
return function(mod,SpecialsPacing)
    mod:hook(SpecialsPacing,"update",function(func,self,...)
        if not mod.is_active() then return func(self,...) end
        local slots=self._specials_slots
        if not slots then return func(self,...) end
        local only_injected=self._only_update_injected_specials
        self._only_update_injected_specials=true
        local parked=self._hed_parked_slots or {}
        self._hed_parked_slots=parked
        local count=0
        for _,slot in ipairs(slots) do
            if not slot.injected and not slot.spawned and not slot.spawner_queue_id
                and type(slot.spawn_timer)=="number" and slot.spawn_timer<=0 then
                slot._hed_parked_timer=slot.spawn_timer
                slot.spawn_timer=math.huge
                count=count+1; parked[count]=slot
            end
        end
        -- Restore temporary state even if an engine/other-mod update fails.
        local ok,result=pcall(func,self,...)
        self._only_update_injected_specials=only_injected
        -- Restore only slots touched by this call; never rescan all slots.
        for i=1,count do
            local slot=parked[i]
            if slot._hed_parked_timer~=nil then
                if slot.spawn_timer==math.huge and not slot.injected and not slot.spawned and not slot.spawner_queue_id then
                    slot.spawn_timer=slot._hed_parked_timer
                end
                slot._hed_parked_timer=nil
            end
            parked[i]=nil
        end
        if not ok then error(result) end
        return result
    end)
end
