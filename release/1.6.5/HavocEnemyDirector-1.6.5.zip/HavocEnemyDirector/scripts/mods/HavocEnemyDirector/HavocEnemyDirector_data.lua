local mod=get_mod("HavocEnemyDirector")
local native_capacity=require("scripts/settings/buff/buff_settings").max_proc_events
return {
    name=mod:localize("mod_name"),description=mod:localize("mod_description"),is_togglable=true,
    options={widgets={
        {setting_id="director_open",type="button",button_text="open",function_name="open_settings"},
        {setting_id="buff_proc_capacity",type="numeric",default_value=native_capacity,
            range={native_capacity,native_capacity*8},decimals_number=0,tooltip="buff_proc_capacity_description"},
    }},
}
