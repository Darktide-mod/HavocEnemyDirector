-- Reconcile live units on the director tick; account for intervening spawns and
-- removals immediately so sharing the snapshot cannot overrun a capacity.
local Population={}
Population.__index=Population
local function change(t,key,amount)
    if key then
        local n=(t[key] or 0)+amount
        t[key]=n~=0 and n or nil
    end
end
local function clear(t) for key in pairs(t) do t[key]=nil end end
function Population.new(breed_for,category_for)
    return setmetatable({breed_for=breed_for,category_for=category_for,epoch=0,total=0,
        categories={},generators={},breeds={},units=setmetatable({},{__mode="k"})},Population)
end
function Population:add(unit,owner,alive)
    if not alive[unit] then return end
    local entry=self.units[unit]
    if not entry then
        local breed=self.breed_for(unit)
        entry={name=breed.name,category=self.category_for(breed)}
        self.units[unit]=entry
    end
    if entry.epoch~=self.epoch then
        entry.epoch=self.epoch
        self.total=self.total+1
        change(self.categories,entry.category,1)
        change(self.breeds,entry.name,1)
        change(self.generators,owner,1)
    elseif entry.owner~=owner then
        change(self.generators,entry.owner,-1)
        change(self.generators,owner,1)
    end
    entry.owner=owner
    return entry
end
function Population:remove(unit)
    local entry=self.units[unit]
    if entry and entry.epoch==self.epoch then
        self.total=self.total-1
        change(self.categories,entry.category,-1)
        change(self.breeds,entry.name,-1)
        change(self.generators,entry.owner,-1)
    end
    self.units[unit]=nil
end
function Population:refresh(units,alive,owners)
    self.epoch=self.epoch+1
    self.total=0
    clear(self.categories); clear(self.generators); clear(self.breeds)
    for _,unit in ipairs(units) do self:add(unit,owners[unit],alive) end
    self.ready=true
end
return Population
