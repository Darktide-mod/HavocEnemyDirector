local mod=get_mod("HavocEnemyDirector")
local base=get_mod("HavocConditionManager")
local solo=get_mod("SoloPlay")
local P=mod.planner
local C=mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/preset_codec")
local Files=mod:io_dofile("HavocEnemyDirector/scripts/mods/HavocEnemyDirector/preset_files")
local A={codec=C}
local store
local function storage()
    if not store then
        local ok,value,err=pcall(Files.new,Mods and Mods.lua and Mods.lua.ffi)
        if not ok or not value then return nil,err or "template_io_unavailable" end
        store=value
    end
    return store
end
local function protect(fn,...)
    local ok,value,err=pcall(fn,...)
    if not ok then return nil,"template_io_failed" end
    return value,err
end
function A.directory()
    local fs,err=storage(); if not fs then return nil,err end
    local ok,e=protect(fs.ensure); if not ok then return nil,e end
    return fs.directory
end
local function settings()
    local s=solo:io_dofile("SoloPlay/scripts/mods/SoloPlay/SoloPlaySettings")
    base.extend_condition_settings(s)
    return s
end
function A.compatible(doc)
    local s=settings()
    for _,id in ipairs(doc.context.conditions) do
        if not s.lookup.havoc_circumstances[id] then return nil,"template_condition_missing: "..id end
    end
    local faction_ok=false
    for _,id in ipairs(s.order.havoc_factions) do if id==doc.context.faction then faction_ok=true end end
    if not faction_ok then return nil,"template_faction_invalid" end
    local mission=solo:get("havoc_mission")
    if solo.parse_mission_params and mission then mission=solo.parse_mission_params(mission) end
    if not base.condition_catalog.environment_available(s,mission,doc.context.environment) then return nil,"template_environment_invalid" end
    return true
end
function A.capture(name)
    name=C.name(name); if not name then return nil,"template_name_invalid" end
    local config=mod.get_config()
    local scaling={}
    for category,value in pairs(mod.get_spawn_scaling()) do scaling[category]={multiplier=value.multiplier,mode=value.mode} end
    return C.validate({format=C.format,version=C.version,name=name,config=config,context={
        conditions=base.get_primary_havoc_conditions(),environment=solo:get("havoc_theme_circumstance") or "default",
        faction=solo:get("havoc_faction") or "mixed",scaling=scaling}},P,mod.breeds)
end
function A.decode(text) return C.decode(text,P,mod.breeds,cjson) end
function A.read(filename)
    if not C.filename(filename) then return nil,"template_name_invalid" end
    local fs,err=storage(); if not fs then return nil,err end
    local text,e=protect(fs.read,filename); if not text then return nil,e end
    return A.decode(text)
end
function A.list()
    local fs,err=storage(); if not fs then return nil,err end
    local filenames,e=protect(fs.list); if not filenames then return nil,e end
    local result={}
    for _,filename in ipairs(filenames) do
        if C.filename(filename) then
            local doc,why=A.read(filename)
            result[#result+1]={file=filename,name=doc and doc.name or filename,document=doc,error=why}
        end
    end
    table.sort(result,function(a,b) return a.name==b.name and a.file<b.file or a.name<b.name end)
    return result
end
function A.save_document(doc,name,overwrite)
    name=C.name(name); if not name then return nil,"template_name_invalid" end
    local copy=P.copy(doc); copy.name=name
    local checked,err=C.validate(copy,P,mod.breeds); if not checked then return nil,err end
    -- Don't export local revision or condition synchronization state.
    checked.config.revision=nil; checked.config.next_id=nil; checked.config.conditions_signature=nil
    local ok,text=pcall(cjson.encode,checked)
    if not ok or #text>C.max_bytes then return nil,"template_too_large" end
    local fs,e=storage(); if not fs then return nil,e end
    local saved,why=protect(fs.write,name..".json",text,overwrite==true)
    if not saved then return nil,why end
    return name..".json"
end
function A.save(name,overwrite)
    local doc,err=A.capture(name); if not doc then return nil,err end
    return A.save_document(doc,name,overwrite)
end
function A.delete(filename)
    if not C.filename(filename) then return nil,"template_name_invalid" end
    local fs,err=storage(); if not fs then return nil,err end
    return protect(fs.remove,filename)
end
function A.export(filename)
    local doc,err=A.read(filename); if not doc then return nil,err end
    local ok,text=pcall(cjson.encode,doc)
    if not ok then return nil,"template_json_invalid" end
    return text
end
function A.apply(doc,view)
    if not mod:is_enabled() or not base:is_enabled() then return nil,"template_disabled" end
    local checked,err=C.validate(doc,P,mod.breeds); if not checked then return nil,err end
    local ok,why=A.compatible(checked); if not ok then return nil,why end
    local previous=A.capture("rollback")
    local function assign(value)
        local x=value.context
        base:set("havoc_circumstances_serialized",table.concat(x.conditions,":"))
        solo:set("havoc_theme_circumstance",x.environment); solo:set("havoc_faction",x.faction)
        for category,f in pairs(x.scaling) do
            base:set("spawn_multiplier_"..category,f.multiplier); base:set("spawn_mode_"..category,f.mode)
        end
        mod.save_config(value.config)
    end
    -- Multiplier callbacks must not reconstruct defaults halfway through a load.
    mod._loading_template=true
    local applied=pcall(assign,checked)
    if not applied and previous then pcall(assign,previous) end
    mod._loading_template=nil
    if not applied then return nil,"template_apply_failed" end
    if view then
        view._current.havoc_circumstances=P.copy(checked.context.conditions)
        view._current.havoc_theme_circumstance=checked.context.environment; view._current.havoc_faction=checked.context.faction
        view._hed_generator_id=nil; view._hcm_offsets={}; view._hcm_refresh=true
        if view._recreate_dropdown then
            view:_recreate_dropdown("havoc_faction"); view:_recreate_dropdown("havoc_theme_circumstance")
        end
        view._pending_condition_refresh=true
    end
    return true
end
mod.presets=A
return A
