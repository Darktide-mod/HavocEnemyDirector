-- Only director-owned specialists join this queue. Native/mission injections,
-- bosses and objective actors keep their original owners and lifetimes.
local Cleanup={}
function Cleanup.new() return {slots={},lookup=setmetatable({},{__mode="k"}),cursor=1} end
function Cleanup.add(state,unit,t)
    if state.lookup[unit] then return end
    local slot={unit=unit,next_stuck_check_t=t+0.5}
    state.lookup[unit]=slot
    state.slots[#state.slots+1]=slot
end
function Cleanup.remove(state,unit)
    local slot=state.lookup[unit]
    if slot then slot.unit=nil; state.lookup[unit]=nil end
end
function Cleanup.update(state,specials,t,alive)
    if not specials or not specials._template or not specials._nav_world
        or type(specials._destroy_special_distance_sq)~="number" or not specials._check_stuck_special then return end
    local slots=state.slots
    local visits,checks=math.min(#slots,8),0
    for _=1,visits do
        if #slots==0 then break end
        local index=state.cursor<=#slots and state.cursor or 1
        local slot=slots[index]
        local unit=slot.unit
        if unit and alive[unit] and t>=slot.next_stuck_check_t then
            -- Use the running game's failure threshold, distance and navigation
            -- checks. Limit costly checks to two per frame; never shorten its
            -- 0.5-second per-unit cadence, even when only one unit remains.
            specials:_check_stuck_special(unit,slot,specials._template,1,t)
            checks=checks+1
        end
        if not slot.unit or not alive[unit] then
            if unit then state.lookup[unit]=nil end
            slots[index]=slots[#slots]; slots[#slots]=nil
            state.cursor=index
        else
            state.cursor=index%#slots+1
        end
        if checks>=2 then break end
    end
end
return Cleanup
