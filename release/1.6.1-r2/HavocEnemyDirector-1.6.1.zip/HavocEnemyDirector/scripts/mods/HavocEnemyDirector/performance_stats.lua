-- Sample each director phase at most once a second. These are elapsed times
-- for sampled calls, not whole-game frame times or a continuous profiler.
local S={}
S.new=function() return {next_report=30,tick={next=0,n=0,sum=0,peak=0},cleanup={next=0,n=0,sum=0,peak=0}} end
S.begin=function(stats,phase,t)
    local timer=Application and Application.time_since_launch
    local entry=stats[phase]
    if not timer or t<entry.next then return end
    entry.next=t+1
    return timer()
end
S.finish=function(stats,phase,start)
    if start==nil then return end
    local elapsed=math.max(0,Application.time_since_launch()-start)*1000
    local entry=stats[phase]
    entry.n=entry.n+1; entry.sum=entry.sum+elapsed; entry.peak=math.max(entry.peak,elapsed)
end
S.report=function(stats,t,log,final)
    if not final and t<stats.next_report then return end
    stats.next_report=t+30
    local tick,cleanup=stats.tick,stats.cleanup
    if tick.n+cleanup.n==0 then return end
    log("Director performance (%s, elapsed=%.1fs): tick samples=%d mean=%.3fms max=%.3fms; cleanup samples=%d mean=%.3fms max=%.3fms",
        final and "mission_end" or "periodic",t,tick.n,tick.sum/math.max(1,tick.n),tick.peak,
        cleanup.n,cleanup.sum/math.max(1,cleanup.n),cleanup.peak)
    for _,entry in ipairs({tick,cleanup}) do entry.n=0; entry.sum=0; entry.peak=0 end
end
return S
